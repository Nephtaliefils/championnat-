<?php
 include './db.php';

 session_start();
 $_SESSION['done1'] = 0;
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styless.css">
    <title>Maches</title>
</head>
<body class="match">
 
<header class="tete">
  <h1>Coupe 3e Infos</h1>
 </header>
        <nav class="menu">
        <ul>
            
          
            <li>
                <a href="#">
                    <h2>Macthes</h2>
                </a>
            </li>
            <li>
                <a href="classement.php">
                    <h2>Classement</h2>
                </a>
            </li>
            <li>
            <a href="logout.php">Déconnexion</a>
           </li>
        </ul>
        
        </nav>
        <div class="sucess">
                    <h1><?php echo $_SESSION['username']; ?>!</h1>
                    
                </div>
     
<!-------- Les Affiches du premier tours pour le groupe A -------->

    <table class="table1">
      <thead>
        <tr>  
          <th> Groupe A</th>
          <th>Affiche</th>
          <th>Score</th>
        </tr>
      </thead>
 
      <form method="Post" action="traitement.php" >  
        <tbody>
          <tr>
            <td>MATCH 1</td>
            
            <td><?php $eqp1 = "SELECT equipe FROM groupea WHERE id=1";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupea WHERE id=2 ";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?></td>
            <td><input type="number" name="score1" min='0' max='10' required=''   value='<?php $aff = "SELECT score1  FROM scorea WHERE id=1";
               $result = mysqli_query($db, $aff); 
               if (mysqli_num_rows($result) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result)) {
                  echo($row["score1"]) ;
                }
              } else {
                echo '';
              }
              
             
               ?>' >
                ------
              <input type="number" name="score2" min='0' max='10' required=''   value='<?php $aff1 = "SELECT score2  FROM scorea WHERE id=1";
               $result = mysqli_query($db, $aff1); 
               if (mysqli_num_rows($result) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result)) {
                  echo ($row["score2"]) ;
                }
              } else {
                echo '';
              }
              
              // mysqli_close($db);
               ?>' ></td> 
              
             
            <td > 
              <input type="hidden" value="1" name="btn">
              <button  type="submit" id="1">  Valider</button>     
            </td>
          </tr>
      </form>

       <form method="Post" action="traitement.php"> 
          <tr>
            <td>MATCH 2</td>
            <td><?php $eqp1 = "SELECT equipe FROM groupea WHERE id=3";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupea WHERE id=4";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?> </td>
            <td><input type="number" name="score3"  min='0' max='10' required=''   value='<?php $afff = "SELECT score1  FROM scorea WHERE id=2";
               $resultt = mysqli_query($db, $afff); 
               if (mysqli_num_rows($resultt) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($resultt)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>
               ----
               <input type="number" name="score4"  min='0' max='10' required=''    value='<?php $af = "SELECT score2  FROM scorea WHERE id=2";
               $resultt = mysqli_query($db, $af); 
               if (mysqli_num_rows($resultt) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($resultt)) {
                  echo ($row["score2"]) ;
                }
              } else {
                echo '';
              }
               ?>'></td>

            <td > 
            <input type="hidden" value="2" name="btn">
              <button  type="submit" id="2">  Valider</button>
           </td>
          </tr>
       </form>

        <form method="Post" action="traitement.php"> 
          <tr>
            <td>MATCH 3</td>
            <td><?php $eqp1 = "SELECT equipe FROM groupea WHERE id=1";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupea WHERE id=3 ";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?> </td>
            <td><input type="number" min='0' max='10' name='score5' required=''   value='<?php $af1 = "SELECT score1  FROM scorea WHERE id=3";
               $resulttt = mysqli_query($db, $af1); 
               if (mysqli_num_rows($resulttt) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($resulttt)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>-----<input type="number" min='0' max='10' name='score6' required=''   value='<?php $af2 = "SELECT score2  FROM scorea WHERE id=3";
               $resulttt = mysqli_query($db, $af2); 
               if (mysqli_num_rows($resulttt) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($resulttt)){
                  echo($row["score2"]) ;
                }
              } else {
                 echo '';
              }
              
               ?>'></td>
            <td > 
            <input type="hidden" value="3" name="btn">
              <button  type="submit" id="3">  Valider</button>
            </td>
          </tr>
        </form>

        
        <form method="Post" action="traitement.php"> 
          <tr>
            <td>MATCH 4</td>
            <td><?php $eqp1 = "SELECT equipe FROM groupea WHERE id=2";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupea WHERE id=4 ";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?></td>
            <td><input type="number" min='0' max='10' name='score7' required=''   value='<?php $affe = "SELECT score1  FROM scorea WHERE id=4";
               $result4 = mysqli_query($db, $affe); 
               if (mysqli_num_rows($result4) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result4)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>-----<input type="number" min='0' max='10' name='score8' required=''   value='<?php $affe2 = "SELECT score2  FROM scorea WHERE id=4";
               $result4 = mysqli_query($db, $affe2); 
               if (mysqli_num_rows($result4) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result4)){
                  echo($row["score2"]) ;
                }
              } else {
                 echo '';
              }
               ?>'></td>
            <td > 
              <input type="hidden" value="4" name="btn">
              <button  type="submit" id="4">  Valider</button>
            </td>
          </tr>
        </form>

        <form method="Post" action="traitement.php"> 
          <tr>
            <td>MATCH 5</td>
            <td><?php $eqp1 = "SELECT equipe FROM groupea WHERE id=1";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupea WHERE id=4";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?></td>
            <td><input type="number" min='0' max='10' name='score9' required=''   value='<?php $a = "SELECT score1  FROM scorea WHERE id=5";
               $result5 = mysqli_query($db, $a); 
               if (mysqli_num_rows($result5) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result5)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>-----<input type="number" min='0' max='10' name='score10'  required=''  value='<?php $a2 = "SELECT score2  FROM scorea WHERE id=5";
               $result5 = mysqli_query($db, $a2); 
               if (mysqli_num_rows($result5) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result5)){
                  echo($row["score2"]) ;
                }
              } else {
                 echo '';
              }
               ?>'></td>
            <td > 
              <input type="hidden" value="5" name="btn">
              <button  type="submit" id="5">  Valider</button>
            </td>
          </tr>
        </form>

        <form method="Post" action="traitement.php">
          <tr>
            <td>MATCH 6</td>
            <td><?php $eqp1 = "SELECT equipe FROM groupea WHERE id=2";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupea WHERE id=3";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?> </td>
            <td><input type="number" min='0' max='10' name='score11' required=''   value='<?php $a3 = "SELECT score1  FROM scorea WHERE id=6";
               $result6 = mysqli_query($db, $a3); 
               if (mysqli_num_rows($result6) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result6)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>-----<input type="number" min='0' max='10' name='score12' required=''   value='<?php $a4 = "SELECT score2  FROM scorea WHERE id=6";
               $result6 = mysqli_query($db, $a4); 
               if (mysqli_num_rows($result6) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result6)){
                  echo($row["score2"]) ;
                }
              } else {
                 echo '';
              }
               ?>'></td>
            <td > 
              <input type="hidden" value="6" name="btn">
              <button  type="submit" id="6">  Valider</button>
            </td>
          </tr>
        </form>
        </tbody>
        <br>
        <br>
    </table>
    
     
       <!-------- Les Affiches du premier tours pour le groupe B -------->
       <table class="table2">
       <br>
       <br>
       <thead>
        <tr>  
         <th> Groupe B</th>
         <th>Affiche</th>
         <th>Score</th>
        </tr>
       </thead>

       <tbody>

        <form method="Post" action="traitement.php">
            <tr>
              <td>MATCH 7</td>
              <td><?php $eqp1 = "SELECT equipe FROM groupeb WHERE id=1";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupeb WHERE id=2 ";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?> </td>
              <td><input type="number" min='0' max='10' name='score13' required=''   value='<?php $af4 = "SELECT score1  FROM scoreb WHERE id=1";
               $result7 = mysqli_query($db, $af4); 
               if (mysqli_num_rows($result7) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result7)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>----<input type="number" min='0' max='10' name='score14' required=''   value='<?php $a5 = "SELECT score2  FROM scoreb WHERE id=1";
               $result7 = mysqli_query($db, $a5); 
               if (mysqli_num_rows($result7) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result7)){
                  echo($row["score2"]) ;
                }
              } else {
                 echo '';
              }
               ?>'></td>
              <td> 
                  <input type="hidden" value="7" name="btn">
                  <button  type="submit" id="7">  Valider</button>
              </td>
            </tr>
        </form>

        <form method="Post" action="traitement.php">
          <tr>
            <td>MATCH 8</td>
            <td><?php $eqp1 = "SELECT equipe FROM groupeb WHERE id=3";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupeb WHERE id=4";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?> </td>
            <td><input type="number" min='0' max='10' name='score15' required=''   value='<?php $a6 = "SELECT score1  FROM scoreb WHERE id=2";
               $result8 = mysqli_query($db, $a6); 
               if (mysqli_num_rows($result8) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result8)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>----<input type="number" min='0' max='10' name='score16' required=''   value='<?php $a7 = "SELECT score2  FROM scoreb WHERE id=2";
               $result8 = mysqli_query($db, $a7); 
               if (mysqli_num_rows($result8) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result8)){
                  echo($row["score2"]) ;
                }
              } else {
                 echo '';
              }
               ?>'></td>
            <td > 
               <input type="hidden" value="8" name="btn">
               <button  type="submit" id="8">  Valider</button>
            </td>
          </tr>
        </form>
        

        <form method="Post" action="traitement.php">
          <tr>
            <td>MATCH 9</td>
            <td><?php $eqp1 = "SELECT equipe FROM groupeb WHERE id=1";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupeb WHERE id=3";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?></td>
            <td><input type="number" min='0' max='10' name='score17' required=''   value='<?php $a8 = "SELECT score1  FROM scoreb WHERE id=3";
               $result9 = mysqli_query($db, $a8); 
               if (mysqli_num_rows($result9) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result9)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>----<input type="number" min='0' max='10' name='score18' required=''   value='<?php $a9 = "SELECT score2  FROM scoreb WHERE id=3";
               $result9 = mysqli_query($db, $a9); 
               if (mysqli_num_rows($result9) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result9)){
                  echo($row["score2"]) ;
                }
              } else {
                 echo '';
              }
               ?>'></td>
            <td > 
              <input type="hidden" value="9" name="btn">
              <button  type="submit" id="9">  Valider</button>
            </td>
          </tr>
        </form>


        <form method="Post" action="traitement.php">
          <tr>
            <td>MATCH 10</td>
            <td><?php $eqp1 = "SELECT equipe FROM groupeb WHERE id=2";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupeb WHERE id=4";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?> </td>
            <td><input type="number" min='0' max='10' name='score19' required=''   value='<?php $a10 = "SELECT score1  FROM scoreb WHERE id=4";
               $result10 = mysqli_query($db, $a10); 
               if (mysqli_num_rows($result10) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result10)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>----<input type="number" min='0' max='10' name='score20' required=''   value='<?php $a11 = "SELECT score2  FROM scoreb WHERE id=4";
               $result11 = mysqli_query($db, $a11); 
               if (mysqli_num_rows($result11) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result11)){
                  echo($row["score2"]) ;
                }
              } else {
                 echo '';
              }
               ?>'></td>
            <td > 
              <input type="hidden" value="10" name="btn">
              <button  type="submit" id="10">  Valider</button>
            </td>
          </tr>
        </form>


        <form method="Post" action="traitement.php">
          <tr>
            <td>MATCH 11</td>
            <td><?php $eqp1 = "SELECT equipe FROM groupeb WHERE id=1";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupeb WHERE id=4";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?></td>
            <td><input type="number" min='0' max='10' name='score21' required=''   value='<?php $a12 = "SELECT score1  FROM scoreb WHERE id=5";
               $result12 = mysqli_query($db, $a12); 
               if (mysqli_num_rows($result12) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result12)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>----<input type="number" min='0' max='10' name='score22' required=''   value='<?php $a13 = "SELECT score2  FROM scoreb WHERE id=5";
               $result12 = mysqli_query($db, $a13); 
               if (mysqli_num_rows($result12) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result12)){
                  echo($row["score2"]) ;
                }
              } else {
                 echo '';
              }
               ?>'></td>
            <td > 
              <input type="hidden" value="11" name="btn">
              <button  type="submit" id="11">  Valider</button>
            </td>
          </tr>
        </form>


        <form method="Post" action="traitement.php">
          <tr>
            <td>MATCH 12</td>
            <td><?php $eqp1 = "SELECT equipe FROM groupeb WHERE id=2";
            $result = mysqli_query($db, $eqp1); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }
            ?> VS 
            <?php $eqp2 = "SELECT equipe FROM groupeb WHERE id=3";
            $result = mysqli_query($db, $eqp2); 
            if (mysqli_num_rows($result) > 0) {
               // output data of each row
             while($row = mysqli_fetch_assoc($result)) {
               echo($row["equipe"]) ;
              }
             } else {
             echo '';
            }?></td>
            <td><input type="number" min='0' max='10' name='score23' required=''   value='<?php $a13 = "SELECT score1  FROM scoreb WHERE id=6";
               $result13 = mysqli_query($db, $a13); 
               if (mysqli_num_rows($result13) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result13)){
                  echo($row["score1"]) ;
                }
              } else {
                 echo '';
              }
               ?>'>----<input type="number" min='0' max='10' name='score24' required=''   value='<?php $a14 = "SELECT score2  FROM scoreb WHERE id=6";
               $result13 = mysqli_query($db, $a14); 
               if (mysqli_num_rows($result13) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result13)){
                  echo($row["score2"]) ;
                }
              } else {
                 echo '';
              }
             
               ?>'></td>
            <td > 
              <input type="hidden" value="12" name="btn">
              <button  type="submit" id="12">  Valider</button>
            </td>
          </tr>
       </form>

       </tbody>
       </table>
        <?php

            $sql = "SELECT btn FROM disabled_btn ";
          $result = mysqli_query($db,$sql);
                      
                if (mysqli_num_rows($result) > 0) {
                  
                while($row = mysqli_fetch_array($result)){
                  echo "<script> document.getElementById(" .$row['btn']. ").disabled=true</script>";
                }
                  
              } 
              

        ?>


</body>
</html>