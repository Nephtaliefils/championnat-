<?php
  include './db.php';
  //include './objet.php';
  // Initialiser la session
  session_start();
  
  // Détruire la session.
  if(session_destroy())
  {
      $sql = "truncate disabled_btn;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate groupea;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate groupeb;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate classement;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate classementb;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate scorea;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate scoreb;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate quardfinalea;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate quardfinaleb;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate scoredemi1;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate scoredemi2;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate final;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate finalp;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate 3emplace;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate champion;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate scorep;";
      $result = mysqli_query($db,$sql);

      $sql = "truncate scoref;";
      $result = mysqli_query($db,$sql);

    // Redirection vers la page de connexion
    header("Location:./index.php");
  }
?>