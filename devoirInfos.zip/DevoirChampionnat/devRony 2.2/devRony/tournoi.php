<?php session_start();

 ?>
<?php
  // Initialiser la session
  // Vérifiez si l'utilisateur est connecté, sinon redirigez-le vers la page de connexion
  if(!isset($_SESSION["username"])){
    header("Location: index.php");
    exit(); 
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE->edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styless.css">
    <title>Coupe 3e Info</title>
</head>
<body>
<header class="tete">
  <h1>Coupe 3e Infos</h1>
 </header>
        <nav class="menu">
        <ul>
            <li>
                <a href="#">
                    <h2>Accueil</h2>
                </a>
            </li>
            <li>
                <a href="matche.php">
                    <h2>Macthes</h2>
                </a>
            </li>
            <li>
                <a href="tirage.php">
                    <h2>Tirage</h2>
                </a>
            </li>
            <li>
                <a href="classement.php">
                    <h2>Classement</h2>
                </a>
            </li>
           <li>
           <a href="logout.php">Déconnexion</a>
           </li>
        </ul>
        
        </nav>
        <div class="sucess">
                    <h1>Bienvenue <?php echo $_SESSION['username']; ?>!</h1>
                    
                </div>
        
        

   
    <?php
      $Equipe=['Bresil','Argentine','France','Italie','Espagne','Allemagne','Portugal','Haiti'];
      $_SESSION['done'] = 0;
    ?>
    
    <table class="table">
            <tr class="header">
                <th>Lot #1</th>
                <th>Lot #2</th>
                <th>Lot #3</th>
                <th>Lot #4</th>
            </tr>
                <div>
                <img class="dra" src="flag/bra.png" width="5%;"/>
                <img class="fra" src="flag/fra.png" width="5%;"/>
                <img class="esp" src="flag/esp.png" width="5%;"/>
                <img class="por" src="flag/por.png" width="5%;"/>
                </div>
                <div>
                <img class="arg" src="flag/arg.png" width="5%;"/>
                <img class="ita" src="flag/ita.png" width="2%;"/>
                <img class="alm" src="flag/alm.png" width="5%;"/>
                <img class="hat" src="flag/hat.png" width="3%;"/>

                </div>
                
        

            <tr>
             <th><?php echo $Equipe[0]; ?> </th>
             <th> <?php echo $Equipe[2]; ?></th>
             <th> <?php echo $Equipe[4]; ?></th>
             <th> <?php echo $Equipe[6]; ?></th>
            </tr>

            <tr>
            <th> <?php echo $Equipe[1]; ?></th>
             <th> <?php echo $Equipe[3]; ?></th>
             <th> <?php echo $Equipe[5]; ?></th>
             <th> <?php echo $Equipe[7]; ?></th>
            </tr>
            </tr>
        </table> 

        <form metho="post" action="tirage.php" >
           <button type="submit" name="tirage">
              Tirage
            </button>
        </form>

          
  </body>
</html>

