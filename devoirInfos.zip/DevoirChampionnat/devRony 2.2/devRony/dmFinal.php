<?php
 include './db.php';
 session_start();
     
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styless.css">
    <title>1/2 FINAL</title>
</head>
<body>
<header class="tete">
  <h1>Coupe 3e Infos</h1>
 </header>
        <nav class="menu">
        <ul>
            <li>
                <a href="matche.php">
                    <h2>Macthes</h2>
                </a>
            </li>
            <li>
                <a href="classement.php">
                    <h2>Classement</h2>
                </a>
            </li>
            <li>
                <a href="#">
                    <h2>1/2 Final</h2>
                </a>
            </li>
            <li>
            <a href="logout.php">Déconnexion</a>
           </li>
        </ul>
        
        </nav>
        <div class="sucess">
                    <h1><?php echo $_SESSION['username']; ?>!</h1>
                    
                </div>

        <?php
              if (isset($_SESSION['demiFinalea'])){
                
                for($i=0; $i<2; $i++)
                {
                       $equipeQualif = $_SESSION['demiFinalea'][0];
                       $sql = "SELECT count(*) FROM quardfinalea";
                       $exsql =  mysqli_query($db, $sql);
                       $res =   mysqli_fetch_array($exsql);
                       $nbl = $res['count(*)'];
            
                       if($nbl < 2){
                         $insrt = "INSERT INTO quardfinalea VALUES ('','$equipeQualif')";
                         if(mysqli_query($db, $insrt)){
            
                         }else {
                           echo "ERREUR:" .mysqli_error($db);
                         }
                       }
            
                       $equipeQualif3 = $_SESSION['demiFinalea'][1];
                       $sql = "SELECT count(*) FROM quardfinalea";
                       $exsql =  mysqli_query($db, $sql);
                       $res =   mysqli_fetch_array($exsql);
                       $nbl = $res['count(*)'];
            
                       if($nbl < 2){
                         $insrt = "INSERT INTO quardfinalea VALUES ('','$equipeQualif3')";
                         if(mysqli_query($db, $insrt)){
            
                         }else {
                           echo "ERREUR:" .mysqli_error($db);
                         }
                       }
                     }
                        $sql = "SELECT * FROM quardfinalea";
                        $result = mysqli_query($db, $sql);
                        
                        if (mysqli_num_rows($result) > 0) {
                          
                          echo "<table class='groupee'>";  
                            echo "<tr class='header'><th> GROUPE A EQUIPE EN 1/2 FINAL</th></tr>";
            
                          while($row = mysqli_fetch_array($result)){
                          echo "<tr>";
                            echo "<td>" .$row['Equipe']. "</td>";
                            echo "</tr>";
                          }
                          mysqli_free_result($result);
                          
                          echo"</table>";
                        } else {
                          echo "";
                          echo "Erreur:".mysqli_error($db);
                        } 
                
            }


            if (isset($_SESSION['demiFinaleb'])){
                       for($i=0; $i<2; $i++)
                          {
                            $equipeQualif1 = $_SESSION['demiFinaleb'][0];
                            $sql = "SELECT count(*) FROM quardfinaleb";
                            $exsql =  mysqli_query($db, $sql);
                            $res =   mysqli_fetch_array($exsql);
                            $nbl = $res['count(*)'];

                            if($nbl < 2){
                            $insrt = "INSERT INTO quardfinaleb VALUES ('','$equipeQualif1')";
                            if(mysqli_query($db, $insrt)){

                            }else {
                                echo "ERREUR:" .mysqli_error($db);
                        
                               }
                            }

                                $equipeQualif2 = $_SESSION['demiFinaleb'][1];
                                $sql = "SELECT count(*) FROM quardfinaleb";
                                $exsql =  mysqli_query($db, $sql);
                                $res =   mysqli_fetch_array($exsql);
                                $nbl = $res['count(*)'];

                                if($nbl < 2){
                                    $insrt = "INSERT INTO quardfinaleb VALUES ('','$equipeQualif2')";
                                    if(mysqli_query($db, $insrt)){

                                    }else {
                                        echo "ERREUR:" .mysqli_error($db);
                                        }
                                    }
                               }

                                $sql = "SELECT * FROM quardfinaleb ";
                                $result = mysqli_query($db, $sql);
                        
                              if (mysqli_num_rows($result) > 0) {
                            
                                    echo "<table class='groupee'>";  
                                    echo "<tr class='header'><th> GROUPE B EQUIPE EN 1/2 FINAL</th></tr>";

                                    while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                    echo "<td>" .$row['Equipe']. "</td>";
                                    echo "</tr>";
                                    }
                                    mysqli_free_result($result);
                                    
                                    echo"</table>";
                                } else {
                                            echo "";
                                            echo "Erreur:".mysqli_error($db);
                                        } 
                }     
            ?>   
            <br>
            <br>
            <br>
           
           
       <?
            if (isset($_SESSION['demiFinalea']) && isset($_SESSION['demiFinaleb']))
            {
        ?>
            <form method="Post" action="traitement.php">
               <table class="groupee">
                    <thead>
                        <tr>  
                          <th>1/2 FINAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php $eqp1 = "SELECT equipe FROM quardfinalea WHERE id=1";
                                $result = mysqli_query($db, $eqp1); 
                                if (mysqli_num_rows($result) > 0) {
                                // output data of each row
                                while($row = mysqli_fetch_assoc($result)) {
                                echo($row["equipe"]) ;
                                }
                                } else {
                                echo '';
                                }
                                ?> VS 
                                <?php $eqp2 = "SELECT equipe FROM quardfinaleb WHERE id=2 ";
                                $result = mysqli_query($db, $eqp2); 
                                if (mysqli_num_rows($result) > 0) {
                                // output data of each row
                                while($row = mysqli_fetch_assoc($result)) {
                                echo($row["equipe"]) ;
                                }
                                } else {
                                echo '';
                                }?>
                            </td>
                                <td><input type="number" name="sc1" min='0' max='10' required=''   value='<?php $aff = "SELECT scoredf1  FROM scoredemi1 WHERE id=1";
                                    $result = mysqli_query($db, $aff); 
                                    if (mysqli_num_rows($result) > 0) {
                                        // output data of each row
                                        while($row = mysqli_fetch_assoc($result)) {
                                        echo($row["scoredf1"]) ;
                                        }
                                    } else {
                                        echo '';
                                    }
                                
                                    ?>' >
                                        ------
                                    <input type="number" name="sc2" min='0' max='10' required=''   value='<?php $aff1 = "SELECT scoredf2  FROM scoredemi1 WHERE id=1";
                                    $result = mysqli_query($db, $aff1); 
                                    if (mysqli_num_rows($result) > 0) {
                                        // output data of each row
                                        while($row = mysqli_fetch_assoc($result)) {
                                        echo ($row["scoredf2"]) ;
                                        }
                                    } else {
                                        echo '';
                                    }
                                    
                                    ?>' >
                                </td> 
                                <td > 
                                    <input type="hidden" value="13" name="btn">
                                    <button  type="submit" id="13">Valider</button>     
                                </td>
                        </tr>
                    </tbody>
                </table>
            </form>
       
            <form method="post" action="traitement.php">
               <table class="groupee">
                    <thead>
                        <tr>  
                          <th>1/2 FINAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php $eqp1 = "SELECT equipe FROM quardfinalea WHERE id=2";
                                $result = mysqli_query($db, $eqp1); 
                                if (mysqli_num_rows($result) > 0) {
                                // output data of each row
                                while($row = mysqli_fetch_assoc($result)) {
                                echo($row["equipe"]) ;
                                }
                                } else {
                                echo '';
                                }
                                ?> VS 
                                <?php $eqp2 = "SELECT equipe FROM quardfinaleb WHERE id=1 ";
                                $result = mysqli_query($db, $eqp2); 
                                if (mysqli_num_rows($result) > 0) {
                                // output data of each row
                                while($row = mysqli_fetch_assoc($result)) {
                                echo($row["equipe"]) ;
                                }
                                } else {
                                echo '';
                                }?>
                            </td>
                            
                            <td>
                                    <input type="number" name="sc3" min='0' max='10' required=''   value='<?php $aff = "SELECT scoredf1  FROM scoredemi2 WHERE id=1";
                                    $result = mysqli_query($db, $aff); 
                                    if (mysqli_num_rows($result) > 0) {
                                        // output data of each row
                                        while($row = mysqli_fetch_assoc($result)) {
                                        echo($row["scoredf1"]) ;
                                        }
                                    } else {
                                        echo '';
                                    }
                                
                                    ?>'>
                                        ------
                                    <input type="number" name="sc4" min='0' max='10' required=''   value='<?php $aff1 = "SELECT scoredf2  FROM scoredemi2 WHERE id=1";
                                    $result = mysqli_query($db, $aff1); 
                                    if (mysqli_num_rows($result) > 0) {
                                        // output data of each row
                                        while($row = mysqli_fetch_assoc($result)) {
                                        echo ($row["scoredf2"]) ;
                                        }
                                    } else {
                                        echo '';
                                    }
                                    
                                     
                                    ?>' >
                            </td> 
                                <td > 
                                    <input type="hidden" value="14" name="btn">
                                    <button  type="submit" id="14">  Valider</button>     
                                </td>
                        </tr>
                    </tbody>
                </table>
            </form>
               
        

            <?php
                if (isset($_SESSION['demiFinalea']) && isset($_SESSION['demiFinaleb'])){

                        $sql = "SELECT * FROM finalp ";
                        $result = mysqli_query($db, $sql);

                        if (mysqli_num_rows($result) > 0) {

                            echo "<table class='groupee'>";  
                            echo "<tr class='header'><th> 3EM PLACE</th></tr>";
                            while($row = mysqli_fetch_array($result)){
                            echo "<tr>";
                             echo "<td>" .$row['Equipe']. "</td>";
                           // echo "<td>" .$row['Equipe2']. "</td>";
                           //print_r($row['Equipe']);
                           
                            echo "</tr>";
                            }
                            mysqli_free_result($result);
                            
                            echo"</table>";
                        } else {
                                    echo "";
                                    echo "Erreur:".mysqli_error($db);
                                } 
                
                            $sql = "SELECT * FROM final ";
                            $result = mysqli_query($db, $sql);

                            if (mysqli_num_rows($result) > 0) {

                                echo "<table class='groupee'>";  
                                echo "<tr class='header'><th>FINALE</th></tr>";

                                while($row = mysqli_fetch_array($result)){
                                echo "<tr>";
                                echo "<td>" .$row['Equipe']. "</td>";
                                echo "</tr>";
                                }
                                mysqli_free_result($result);
                                
                                echo"</table>";
                            } else {
                                        echo "";
                                        echo "Erreur:".mysqli_error($db);
                                    } 
                    }
               
                    
                   //******************3EM PLACE************************
               ?>

                        <br>
                        <br>
                        <br>
                        <br>
        <?php
                if (isset($_SESSION['demiFinalea']) && isset($_SESSION['demiFinaleb'])){

        ?>
                   <form method="Post" action="traitement.php">
                     <table class="groupee">
                         <thead>
                             <tr>  
                               <th>3EM PLACE</th>
                             </tr>
                         </thead>
                         <tbody>
                             <tr>
                                 <td><?php $eqp1 = "SELECT equipe FROM finalp WHERE id=1";
                                     $result = mysqli_query($db, $eqp1); 
                                     if (mysqli_num_rows($result) > 0) {
                                     // output data of each row
                                     while($row = mysqli_fetch_assoc($result)) {
                                     echo($row["equipe"]) ;
                                     }
                                     } else {
                                     echo '';
                                     }
                                     ?> VS 
                                     <?php $eqp2 = "SELECT equipe FROM finalp WHERE id=2 ";
                                     $result = mysqli_query($db, $eqp2); 
                                     if (mysqli_num_rows($result) > 0) {
                                     // output data of each row
                                     while($row = mysqli_fetch_assoc($result)) {
                                     echo($row["equipe"]) ;
                                     }
                                     } else {
                                     echo '';
                                     }?>
                                  </td>
                                   </td>
                                     <td><input type="number" name="but1" min='0' max='10' required=''   value='<?php $aff = "SELECT score1  FROM scorep WHERE id=1";
                                         $result = mysqli_query($db, $aff); 
                                         if (mysqli_num_rows($result) > 0) {
                                             // output data of each row
                                             while($row = mysqli_fetch_assoc($result)) {
                                             echo($row["score1"]) ;
                                             }
                                         } else {
                                             echo '';
                                         }
                                     
                                         ?>' >
                                             ------
                                         <input type="number" name="but2" min='0' max='10' required=''   value='<?php $aff1 = "SELECT score2  FROM scorep WHERE id=1";
                                         $result = mysqli_query($db, $aff1); 
                                         if (mysqli_num_rows($result) > 0) {
                                             // output data of each row
                                             while($row = mysqli_fetch_assoc($result)) {
                                             echo ($row["score2"]);
                                             }
                                         } else {
                                             echo '';
                                         }
                                         
                                         // mysqli_close($db);
                                         ?>' >
                                     </td> 
                                        <td > 
                                            <input type="hidden" value="15" name="btn">
                                            <button  type="submit" id="15">Valider</button>     
                                        </td>
                                 </td>
                             </tr>
                         </tbody>
                     </table>
                 </form>

                 
     
                 <form method="post" action="traitement.php">
                    <table class="groupee">
                         <thead>
                             <tr>  
                               <th>FINAL</th>
                             </tr>
                         </thead>
                         <tbody>
                             <tr>
                                 <td><?php $eqp1 = "SELECT equipe FROM final WHERE id=1";
                                     $result = mysqli_query($db, $eqp1); 
                                     if (mysqli_num_rows($result) > 0) {
                                     // output data of each row
                                     while($row = mysqli_fetch_assoc($result)) {
                                     echo($row["equipe"]) ;
                                     }
                                     } else {
                                     echo '';
                                     }
                                     ?> VS 
                                     <?php $eqp2 = "SELECT equipe FROM final WHERE id=2 ";
                                     $result = mysqli_query($db, $eqp2); 
                                     if (mysqli_num_rows($result) > 0) {
                                     // output data of each row
                                     while($row = mysqli_fetch_assoc($result)) {
                                     echo($row["equipe"]) ;
                                     }
                                     } else {
                                     echo '';
                                     }?></td>
                                 <td>
                                     <td><input type="number" name="but3" min='0' max='10' required=''   value='<?php $aff = "SELECT score1  FROM scoref WHERE id=1";
                                         $result = mysqli_query($db, $aff); 
                                         if (mysqli_num_rows($result) > 0) {
                                             // output data of each row
                                             while($row = mysqli_fetch_assoc($result)) {
                                             echo($row["score1"]) ;
                                             }
                                         } else {
                                             echo '';
                                         }
                                     
                                         ?>' >
                                             ------
                                         <input type="number" name="but4" min='0' max='10' required=''   value='<?php $aff1 = "SELECT score2  FROM scoref WHERE id=1";
                                         $result = mysqli_query($db, $aff1); 
                                         if (mysqli_num_rows($result) > 0) {
                                             // output data of each row
                                             while($row = mysqli_fetch_assoc($result)) {
                                             echo ($row["score2"]) ;
                                             }
                                         } else {
                                             echo '';
                                         }
                                         
                                          
                                         ?>' >
                                     </td> 
                                     <td > 
                                         <input type="hidden" value="16" name="btn">
                                         <button  type="submit" id="16">  Valider</button>     
                                     </td>
                                 </td>
                             </tr>
                         </tbody>
                     </table>
                </form>
        
   <?php
                }
   ?>

        <?php
                $sql = "SELECT btn FROM disabled_btn ";
                $result = mysqli_query($db,$sql);
                        
                    if (mysqli_num_rows($result) > 0) {
                    
                    while($row = mysqli_fetch_array($result)){
                    echo "<script> document.getElementById(" .$row['btn']. ").disabled=true</script>";
                    }
                } 
                mysqli_close($db);
            ?>  
            
 </body>
</html>