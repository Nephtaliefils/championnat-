<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'championnat';



$db = mysqli_connect($host,$username,$password,$dbname) or die ('Connexion impossible');
?>