<?php
 include './db.php';
 include './objet.php';
 //include './traitement';
 session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styless.css">
    <title>CLASSEMENT</title>
</head>
<body class="classement">

<header classement="tete">
  <h1>Coupe 3e Infos</h1>
 </header>
        <nav class="menu">
        <ul>
            <li>
                <a href="matche.php">
                    <h2>Macthes</h2>
                </a>
            </li>
      
            <li>
                <a href="#">
                    <h2>Classement</h2>
                </a>
            </li>
            <li>
                <a href="dmFinal.php">
                    <h2>1/2 Final</h2>
                </a>
            </li>
            <li>
            <a href="logout.php">Déconnexion</a>
           </li>
        </ul>
        
        </nav>
        <div class="sucess">
                    <h1><?php echo $_SESSION['username']; ?>!</h1>
                    
                </div>

<?php  
    if (isset($_SESSION['equipeA'])){
   
              
        function comparator($equipe1,$equipe2)
          {
            return $equipe2->getPoint() > $equipe1->getPoint();
  
          }
       

  ?>

 

<!-------- equipeAssement -------->
<!-------- equipeAssement pour le groupe A -------->

<?php
        

            for($i=0; $i<4; $i++){

              $sql3 = "UPDATE classement SET
                    mj = ".$_SESSION ['equipeA'][$i]->getMJ().",
                    mg = ".$_SESSION ['equipeA'][$i]->getMG().", 
                    mn = ".$_SESSION ['equipeA'][$i]->getMN().",
                    mp = ".$_SESSION ['equipeA'][$i]->getMP().", 
                    bp = ".$_SESSION ['equipeA'][$i]->getBP().",
                    bc = ".$_SESSION ['equipeA'][$i]->getBC().", 
                    dif = ".$_SESSION ['equipeA'][$i]->getDIF().", 
                    nbpoint = ".$_SESSION ['equipeA'][$i]->getPOINT()." 
                    WHERE no = ($i+1)";
                    // var_dump($_SESSION ['equipeA'][$i]->getMJ());
                    if(mysqli_query($db, $sql3)){

                    }else {
                      echo "ERREUR:" .mysqli_error($db);
                    }
                    // }
          }

              $sql = "SELECT  * FROM classement";
              $result = mysqli_query($db, $sql);
              
              if (mysqli_num_rows($result) > 0) {
                echo "<table class='tab'>";  
                echo "<tr><th>CLASSEMENT A</th></tr>
                            <tr>
                            <th></th>
                            <th>MJ</th>
                            <th>MG</th>
                            <th>MN</th>
                            <th>MP</th>
                            <th>BP</th>
                            <th>BC</th>
                            <th>DIFF</th>
                            <th>POINTS</th>
                            </tr>";
                $i = 0;
                  while($row = mysqli_fetch_array($result)){
                    $_SESSION['equipeA'][$i] = new Equipe($row['nom'],$row['mj'],$row['mg'],$row['mn'],$row['mp'],$row['bp'],$row['bc'],$row['dif'],$row['nbpoint']);
                      $i++;
                  }    
                         
                          usort($_SESSION ['equipeA'],'comparator');
                     
              
                  for ($i=0; $i <4 ; $i++) { 
                      echo "<td>" .$_SESSION ['equipeA'][$i]->getName(). "</td>";
                      echo "<td>" .$_SESSION ['equipeA'][$i]->getMJ(). "</td>";
                      echo "<td>" .$_SESSION ['equipeA'][$i]->getMG(). "</td>";
                      echo "<td>" .$_SESSION ['equipeA'][$i]->getMN(). "</td>";
                      echo "<td>" .$_SESSION ['equipeA'][$i]->getMP(). "</td>";
                      echo "<td>" .$_SESSION ['equipeA'][$i]->getBP(). "</td>";
                      echo "<td>" .$_SESSION ['equipeA'][$i]->getBC(). "</td>";
                      echo "<td>" .$_SESSION ['equipeA'][$i]->getDIF(). "</td>";
                      echo "<td>" .$_SESSION ['equipeA'][$i]->getPOINT(). "</td>";
                    echo "</tr>";
                  }
                  // $_SESSION['equipeA'][$i] = $_SESSION['equipeA'] ;
              }
            
              
              ////DEequipeARATION DE VARIABLE POUR GERER LA 1/2 FINAL GROUPE A
               $eqp1 = $_SESSION['equipeA'][0]->getMJ(); 
               $eqp2 = $_SESSION['equipeA'][1]->getMJ();
               $eqp3 = $_SESSION['equipeA'][2]->getMJ(); 
               $eqp4 = $_SESSION['equipeA'][3]->getMJ();
               
                  //print_r($_SESSION['equipeA'][0]->getMJ());

               //VERIFIER SI TOUT LES EQUIPES ON JOUER 3 MATCHES
               if ($eqp1==3) {
                if ($eqp1==$eqp2) {
                    if ($eqp2==$eqp3) {
                        if ($eqp3==$eqp4) {
                              usort($_SESSION ['equipeA'],'comparator');
                            $_SESSION['demiFinalea'][0] = $_SESSION ['equipeA'][0]->getName();
                            $_SESSION['demiFinalea'][1] = $_SESSION ['equipeA'][1]->getName();

                        
              // print_r( $_SESSION['demiFinalea'][0]);
              // print_r( $_SESSION['demiFinalea'][1]);

          
    
          }
        }
      }
    }
}
?>

       
<?php 
	     	if (isset($_SESSION['equipeB']) ){
         
          for($i=0; $i<4; $i++){

            $sql3 = "UPDATE classementb SET
                  mj = ".$_SESSION ['equipeB'][$i]->getMJ().",
                  mg = ".$_SESSION ['equipeB'][$i]->getMG().", 
                  mn = ".$_SESSION ['equipeB'][$i]->getMN().",
                  mp = ".$_SESSION ['equipeB'][$i]->getMP().", 
                  bp = ".$_SESSION ['equipeB'][$i]->getBP().",
                  bc = ".$_SESSION ['equipeB'][$i]->getBC().", 
                  dif = ".$_SESSION ['equipeB'][$i]->getDIF().", 
                  nbpoint = ".$_SESSION ['equipeB'][$i]->getPOINT()." 
                  WHERE no = ($i+1)";
                 // var_dump($_SESSION ['equipeB'][$i]->getMJ());
                  if(mysqli_query($db, $sql3)){
       
                  }else {
                    echo "ERREUR:" .mysqli_error($db);
                  }
                 // }
       }
       
             $sql = "SELECT  * FROM classementb";
             $result = mysqli_query($db, $sql);
             
             if (mysqli_num_rows($result) > 0) {
               echo "<table class='tab'>";  
            echo "<tr><th>CLASSEMENT B</th></tr>
                           <tr>
                           <th></th>
                           <th>MJ</th>
                           <th>MG</th>
                           <th>MN</th>
                           <th>MP</th>
                           <th>BP</th>
                           <th>BC</th>
                           <th>DIFF</th>
                           <th>POINTS</th>
                           </tr>";
               $i = 0;
                 while($row = mysqli_fetch_array($result)){
                   $_SESSION ['equipeB'][$i] = new Equipe($row['nom'],$row['mj'],$row['mg'],$row['mn'],$row['mp'],$row['bp'],$row['bc'],$row['dif'],$row['nbpoint']);
                    $i++;
                 }
                 usort( $_SESSION ['equipeB'],'comparator');
                
                 for ($i=0; $i <4 ; $i++) { 
                   # code...
                   echo "<tr>";
                     
                     echo "<td>" .$_SESSION ['equipeB'][$i]->getName(). "</td>";
                     echo "<td>" .$_SESSION ['equipeB'][$i]->getMJ(). "</td>";
                     echo "<td>" .$_SESSION ['equipeB'][$i]->getMG(). "</td>";
                     echo "<td>" .$_SESSION ['equipeB'][$i]->getMN(). "</td>";
                     echo "<td>" .$_SESSION ['equipeB'][$i]->getMP(). "</td>";
                     echo "<td>" .$_SESSION ['equipeB'][$i]->getBP(). "</td>";
                     echo "<td>" .$_SESSION ['equipeB'][$i]->getBC(). "</td>";
                     echo "<td>" .$_SESSION ['equipeB'][$i]->getDIF(). "</td>";
                     echo "<td>" .$_SESSION ['equipeB'][$i]->getPOINT(). "</td>";
                   echo "</tr>";
                 }
                 
                  
             }
            
             //DEequipeARATION DE VARIABLE POUR GERER LA 1/2 FINAL GROUPE b
             $equipe1 = $_SESSION['equipeB'][0]->getMJ(); 
             $equipe2 = $_SESSION['equipeB'][1]->getMJ();
             $equipe3 = $_SESSION['equipeB'][2]->getMJ(); 
             $equipe4 = $_SESSION['equipeB'][3]->getMJ();
             //print_r($_SESSION['equipeB'][0]->getMJ());

             //VERIFIER SI TOUT LES EQUIPES ON JOUER 3 MATCHES
             if ($equipe1==3) {
              if ($equipe1==$equipe2) {
                  if ($equipe2==$equipe3) {
                      if ($equipe3==$equipe4) {
                            usort($_SESSION ['equipeB'],'comparator');
                          $_SESSION['demiFinaleb'][0] =  $_SESSION['equipeB'][0]->getName();
                          $_SESSION['demiFinaleb'][1] =  $_SESSION['equipeB'][1]->getName();
                            // print_r( $_SESSION['demiFinaleb'][1]);

      
        }
      }
    }
  } 
}
    
?>
   
</body>
</html>