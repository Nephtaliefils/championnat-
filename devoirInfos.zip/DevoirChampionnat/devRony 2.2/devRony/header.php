<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet"  href="styles.css">
</head>
    <body>
        <header>
            <div class="sidebar-button">
                <h1>Coupe Du Monde</h1>
                <h2>3em Info</h2>
            </div>
        </header>
        <nav>
            <ul>
            	<li><a href="index.php"><li>Equipe</li></a>
            	<li><a href="classement.php"><li>Classement</li></a>
            </ul>

		</nav>
    </body>
</html>

