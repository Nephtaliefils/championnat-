
<?php
   include './objet.php';
   include './db.php';
    session_start();
    $btn = $_POST['btn'];

     $req = "INSERT INTO DISABLED_BTN VALUES(null,$btn)";
     mysqli_query($db,$req);
?>



<?php
  if( isset($_POST['score1']) && isset($_POST['score2']) ) {
     $score1 = $_POST['score1'];
     $score2 = $_POST['score2'];
     
    
                 // array_push($_SESSION['disable'],$_POST['test']);

                  $sql = "INSERT INTO scorea VALUES ('','$score1','$score2' )";

                  if (mysqli_query($db, $sql)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sql . "<br>" . mysqli_error($db);
                  }
                  

                    //mysqli_close($db);

                    
                    
                    if($score1 > $score2){
                      $_SESSION ['equipeA'][0]->setMJ($_SESSION ['equipeA'][0]->getMJ()+1);
                      $_SESSION ['equipeA'][1]->setMJ($_SESSION ['equipeA'][1]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][0]->setMG($_SESSION ['equipeA'][0]->getMG()+1);
                      $_SESSION ['equipeA'][1]->setMP($_SESSION ['equipeA'][1]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeA'][0]->setBP($_SESSION ['equipeA'][0]->getBP()+$score1);
                    $_SESSION ['equipeA'][1]->setBP($_SESSION ['equipeA'][1]->getBP()+$score2);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeA'][0]->setBC($_SESSION ['equipeA'][0]->getBC()+$score2);
                    $_SESSION ['equipeA'][1]->setBC($_SESSION ['equipeA'][1]->getBC()+$score1);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][0]->setDIF( $_SESSION ['equipeA'][0]->getBP() - $_SESSION ['equipeA'][0]->getBC() );
                    $_SESSION ['equipeA'][1]->setDIF($_SESSION ['equipeA'][1]->getBP() - $_SESSION ['equipeA'][1]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][0]->setPOINT( $_SESSION ['equipeA'][0]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score2 > $score1){
                      $_SESSION ['equipeA'][0]->setMJ($_SESSION ['equipeA'][0]->getMJ()+1);
                      $_SESSION ['equipeA'][1]->setMJ($_SESSION ['equipeA'][1]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][1]->setMG($_SESSION ['equipeA'][1]->getMG()+1);
                      $_SESSION ['equipeA'][0]->setMP($_SESSION ['equipeA'][0]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeA'][0]->setBP($_SESSION ['equipeA'][0]->getBP()+$score1);
                    $_SESSION ['equipeA'][1]->setBP($_SESSION ['equipeA'][1]->getBP()+$score2);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeA'][0]->setBC($_SESSION ['equipeA'][0]->getBC()+$score2);
                    $_SESSION ['equipeA'][1]->setBC($_SESSION ['equipeA'][1]->getBC()+$score1);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][0]->setDIF( $_SESSION ['equipeA'][0]->getBP() - $_SESSION ['equipeA'][0]->getBC());
                    $_SESSION ['equipeA'][1]->setDIF(   $_SESSION ['equipeA'][1]->getBP() - $_SESSION ['equipeA'][1]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][1]->setPOINT( $_SESSION ['equipeA'][1]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeA'][0]->setMJ($_SESSION ['equipeA'][0]->getMJ()+1);
                      $_SESSION ['equipeA'][1]->setMJ($_SESSION ['equipeA'][1]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeA'][0]->setMN($_SESSION ['equipeA'][0]->getMN()+1);
                      $_SESSION ['equipeA'][1]->setMN($_SESSION ['equipeA'][1]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeA'][0]->setBP($_SESSION ['equipeA'][0]->getBP()+$score2);
                    $_SESSION ['equipeA'][1]->setBP($_SESSION ['equipeA'][1]->getBP()+$score1);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeA'][0]->setBC($_SESSION ['equipeA'][0]->getBC()+$score1);
                    $_SESSION ['equipeA'][1]->setBC($_SESSION ['equipeA'][1]->getBC()+$score2);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][0]->setDIF( $_SESSION ['equipeA'][0]->getBC() -  $_SESSION ['equipeA'][0]->getBP());
                    $_SESSION ['equipeA'][1]->setDIF( $_SESSION ['equipeA'][1]->getBC() -  $_SESSION ['equipeA'][1]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][0]->setPOINT( $_SESSION ['equipeA'][0]->getPOINT()+1);
                        $_SESSION ['equipeA'][1]->setPOINT( $_SESSION ['equipeA'][1]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                  
                }
                
              }

              header("location:./matche.php");
              ?>

              

              <?php
                  //**************************************TRAITEMENT 2EM MATCH ************************************
                if( isset($_POST['score3']) && isset($_POST['score4']) ) {
                  $score3 = $_POST['score3'];
                  $score4 = $_POST['score4'];
                
                

                  $sc2 = "INSERT INTO scorea VALUES ('','$score3','$score4' )";

                  if (mysqli_query($db, $sc2)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc2 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);


                    if($score3 > $score4){
                      $_SESSION ['equipeA'][2]->setMJ($_SESSION ['equipeA'][2]->getMJ()+1);
                      $_SESSION ['equipeA'][3]->setMJ($_SESSION ['equipeA'][3]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][2]->setMG($_SESSION ['equipeA'][2]->getMG()+1);
                      $_SESSION ['equipeA'][3]->setMP($_SESSION ['equipeA'][3]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeA'][2]->setBP($_SESSION ['equipeA'][2]->getBP()+$score3);
                    $_SESSION ['equipeA'][3]->setBP($_SESSION ['equipeA'][3]->getBP()+$score4);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeA'][2]->setBC($_SESSION ['equipeA'][2]->getBC()+$score4);
                    $_SESSION ['equipeA'][3]->setBC($_SESSION ['equipeA'][3]->getBC()+$score3);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][2]->setDIF( $_SESSION ['equipeA'][2]->getBP() - $_SESSION ['equipeA'][2]->getBC() );
                    $_SESSION ['equipeA'][3]->setDIF($_SESSION ['equipeA'][3]->getBP() - $_SESSION ['equipeA'][3]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][2]->setPOINT( $_SESSION ['equipeA'][2]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score4 > $score3){
                      $_SESSION ['equipeA'][2]->setMJ($_SESSION ['equipeA'][2]->getMJ()+1);
                      $_SESSION ['equipeA'][3]->setMJ($_SESSION ['equipeA'][3]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][3]->setMG($_SESSION ['equipeA'][3]->getMG()+1);
                      $_SESSION ['equipeA'][2]->setMP($_SESSION ['equipeA'][2]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeA'][2]->setBP($_SESSION ['equipeA'][2]->getBP()+$score3);
                    $_SESSION ['equipeA'][3]->setBP($_SESSION ['equipeA'][3]->getBP()+$score4);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeA'][2]->setBC($_SESSION ['equipeA'][2]->getBC()+$score4);
                    $_SESSION ['equipeA'][3]->setBC($_SESSION ['equipeA'][3]->getBC()+$score3);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][2]->setDIF( $_SESSION ['equipeA'][2]->getBP() - $_SESSION ['equipeA'][2]->getBC());
                    $_SESSION ['equipeA'][3]->setDIF(   $_SESSION ['equipeA'][3]->getBP() - $_SESSION ['equipeA'][3]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][3]->setPOINT( $_SESSION ['equipeA'][3]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeA'][2]->setMJ($_SESSION ['equipeA'][2]->getMJ()+1);
                      $_SESSION ['equipeA'][3]->setMJ($_SESSION ['equipeA'][3]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeA'][2]->setMN($_SESSION ['equipeA'][2]->getMN()+1);
                      $_SESSION ['equipeA'][3]->setMN($_SESSION ['equipeA'][3]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeA'][2]->setBP($_SESSION ['equipeA'][2]->getBP()+$score4);
                    $_SESSION ['equipeA'][3]->setBP($_SESSION ['equipeA'][3]->getBP()+$score3);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeA'][2]->setBC($_SESSION ['equipeA'][2]->getBC()+$score3);
                    $_SESSION ['equipeA'][3]->setBC($_SESSION ['equipeA'][3]->getBC()+$score4);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][2]->setDIF( $_SESSION ['equipeA'][2]->getBC() -  $_SESSION ['equipeA'][2]->getBP());
                    $_SESSION ['equipeA'][3]->setDIF( $_SESSION ['equipeA'][3]->getBC() -  $_SESSION ['equipeA'][3]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][2]->setPOINT( $_SESSION ['equipeA'][2]->getPOINT()+1);
                        $_SESSION ['equipeA'][3]->setPOINT( $_SESSION ['equipeA'][3]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                    
                    
                
                    
                }
                
              }
              header("location:./matche.php");
              ?>


              <?php
                  //**************************************TRAITEMENT 3EM MATCH ************************************
                if( isset($_POST['score5']) && isset($_POST['score6']) ) {
                  $score5 = $_POST['score5'];
                  $score6 = $_POST['score6'];
                
                

                  $sc3 = "INSERT INTO scorea VALUES ('','$score5','$score6')";

                  if (mysqli_query($db, $sc3)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc3 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);

                    if($score5 > $score6){
                      $_SESSION ['equipeA'][0]->setMJ($_SESSION ['equipeA'][2]->getMJ()+1);
                      $_SESSION ['equipeA'][2]->setMJ($_SESSION ['equipeA'][3]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][0]->setMG($_SESSION ['equipeA'][2]->getMG()+1);
                      $_SESSION ['equipeA'][2]->setMP($_SESSION ['equipeA'][3]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeA'][0]->setBP($_SESSION ['equipeA'][2]->getBP()+$score5);
                    $_SESSION ['equipeA'][2]->setBP($_SESSION ['equipeA'][3]->getBP()+$score6);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeA'][0]->setBC($_SESSION ['equipeA'][2]->getBC()+$score6);
                    $_SESSION ['equipeA'][2]->setBC($_SESSION ['equipeA'][3]->getBC()+$score5);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][0]->setDIF( $_SESSION ['equipeA'][2]->getBP() - $_SESSION ['equipeA'][2]->getBC() );
                    $_SESSION ['equipeA'][2]->setDIF($_SESSION ['equipeA'][3]->getBP() - $_SESSION ['equipeA'][3]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][0]->setPOINT( $_SESSION ['equipeA'][0]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score6 > $score5){
                      $_SESSION ['equipeA'][0]->setMJ($_SESSION ['equipeA'][0]->getMJ()+1);
                      $_SESSION ['equipeA'][2]->setMJ($_SESSION ['equipeA'][2]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][2]->setMG($_SESSION ['equipeA'][0]->getMG()+1);
                      $_SESSION ['equipeA'][0]->setMP($_SESSION ['equipeA'][2]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeA'][0]->setBP($_SESSION ['equipeA'][0]->getBP()+$score5);
                    $_SESSION ['equipeA'][2]->setBP($_SESSION ['equipeA'][2]->getBP()+$score6);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeA'][0]->setBC($_SESSION ['equipeA'][0]->getBC()+$score6);
                    $_SESSION ['equipeA'][2]->setBC($_SESSION ['equipeA'][2]->getBC()+$score5);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][0]->setDIF( $_SESSION ['equipeA'][0]->getBP() - $_SESSION ['equipeA'][0]->getBC());
                    $_SESSION ['equipeA'][2]->setDIF(   $_SESSION ['equipeA'][2]->getBP() - $_SESSION ['equipeA'][2]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][2]->setPOINT( $_SESSION ['equipeA'][2]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeA'][0]->setMJ($_SESSION ['equipeA'][0]->getMJ()+1);
                      $_SESSION ['equipeA'][2]->setMJ($_SESSION ['equipeA'][2]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeA'][0]->setMN($_SESSION ['equipeA'][0]->getMN()+1);
                      $_SESSION ['equipeA'][2]->setMN($_SESSION ['equipeA'][2]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeA'][0]->setBP($_SESSION ['equipeA'][0]->getBP()+$score6);
                    $_SESSION ['equipeA'][2]->setBP($_SESSION ['equipeA'][2]->getBP()+$score5);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeA'][0]->setBC($_SESSION ['equipeA'][0]->getBC()+$score5);
                    $_SESSION ['equipeA'][2]->setBC($_SESSION ['equipeA'][2]->getBC()+$score6);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][0]->setDIF( $_SESSION ['equipeA'][0]->getBC() -  $_SESSION ['equipeA'][0]->getBP());
                    $_SESSION ['equipeA'][2]->setDIF( $_SESSION ['equipeA'][2]->getBC() -  $_SESSION ['equipeA'][2]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][0]->setPOINT( $_SESSION ['equipeA'][0]->getPOINT()+1);
                        $_SESSION ['equipeA'][2]->setPOINT( $_SESSION ['equipeA'][2]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                  
                }
                
              }
              header("location:./matche.php");
              ?>


              
              <?php
                  //**************************************TRAITEMENT 4EM MATCH ************************************
                if( isset($_POST['score7']) && isset($_POST['score8']) ) {
                  $score7 = $_POST['score7'];
                  $score8 = $_POST['score8'];
                
                

                  $sc4 = "INSERT INTO scorea VALUES ('','$score7','$score8')";

                  if (mysqli_query($db, $sc4)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc4 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);

                    if($score7 > $score8){
                      $_SESSION ['equipeA'][1]->setMJ($_SESSION ['equipeA'][1]->getMJ()+1);
                      $_SESSION ['equipeA'][3]->setMJ($_SESSION ['equipeA'][3]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][1]->setMG($_SESSION ['equipeA'][1]->getMG()+1);
                      $_SESSION ['equipeA'][3]->setMP($_SESSION ['equipeA'][3]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeA'][1]->setBP($_SESSION ['equipeA'][1]->getBP()+$score7);
                    $_SESSION ['equipeA'][3]->setBP($_SESSION ['equipeA'][3]->getBP()+$score8);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeA'][1]->setBC($_SESSION ['equipeA'][1]->getBC()+$score7);
                    $_SESSION ['equipeA'][3]->setBC($_SESSION ['equipeA'][3]->getBC()+$score8);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][1]->setDIF( $_SESSION ['equipeA'][1]->getBP() - $_SESSION ['equipeA'][1]->getBC() );
                    $_SESSION ['equipeA'][3]->setDIF($_SESSION ['equipeA'][3]->getBP() - $_SESSION ['equipeA'][3]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][1]->setPOINT( $_SESSION ['equipeA'][1]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score8 > $score7){
                      $_SESSION ['equipeA'][1]->setMJ($_SESSION ['equipeA'][1]->getMJ()+1);
                      $_SESSION ['equipeA'][3]->setMJ($_SESSION ['equipeA'][3]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][3]->setMG($_SESSION ['equipeA'][3]->getMG()+1);
                      $_SESSION ['equipeA'][1]->setMP($_SESSION ['equipeA'][1]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeA'][1]->setBP($_SESSION ['equipeA'][1]->getBP()+$score7);
                    $_SESSION ['equipeA'][3]->setBP($_SESSION ['equipeA'][3]->getBP()+$score8);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeA'][1]->setBC($_SESSION ['equipeA'][1]->getBC()+$score8);
                    $_SESSION ['equipeA'][3]->setBC($_SESSION ['equipeA'][3]->getBC()+$score7);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][1]->setDIF( $_SESSION ['equipeA'][1]->getBP() - $_SESSION ['equipeA'][1]->getBC());
                    $_SESSION ['equipeA'][3]->setDIF(   $_SESSION ['equipeA'][3]->getBP() - $_SESSION ['equipeA'][3]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][3]->setPOINT( $_SESSION ['equipeA'][3]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeA'][1]->setMJ($_SESSION ['equipeA'][1]->getMJ()+1);
                      $_SESSION ['equipeA'][3]->setMJ($_SESSION ['equipeA'][3]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeA'][1]->setMN($_SESSION ['equipeA'][1]->getMN()+1);
                      $_SESSION ['equipeA'][3]->setMN($_SESSION ['equipeA'][3]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeA'][1]->setBP($_SESSION ['equipeA'][1]->getBP()+$score7);
                    $_SESSION ['equipeA'][3]->setBP($_SESSION ['equipeA'][3]->getBP()+$score8);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeA'][1]->setBC($_SESSION ['equipeA'][1]->getBC()+$score8);
                    $_SESSION ['equipeA'][3]->setBC($_SESSION ['equipeA'][3]->getBC()+$score7);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][1]->setDIF( $_SESSION ['equipeA'][1]->getBC() -  $_SESSION ['equipeA'][1]->getBP());
                    $_SESSION ['equipeA'][3]->setDIF( $_SESSION ['equipeA'][3]->getBC() -  $_SESSION ['equipeA'][3]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][1]->setPOINT( $_SESSION ['equipeA'][1]->getPOINT()+1);
                        $_SESSION ['equipeA'][3]->setPOINT( $_SESSION ['equipeA'][3]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                  
                }
                
              }
              header("location:./matche.php");
              ?>



              <?php
                  //**************************************TRAITEMENT 5EM MATCH ************************************
                if( isset($_POST['score9']) && isset($_POST['score10']) ) {
                  $score9 = $_POST['score9'];
                  $score10 = $_POST['score10'];
                
                

                  $sc5 = "INSERT INTO scorea VALUES ('','$score9','$score10')";

                  if (mysqli_query($db, $sc5)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc5 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);


                      
                    
                      
                    
                    
                    if($score9 > $score10){
                      $_SESSION ['equipeA'][0]->setMJ($_SESSION ['equipeA'][0]->getMJ()+1);
                      $_SESSION ['equipeA'][3]->setMJ($_SESSION ['equipeA'][3]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][0]->setMG($_SESSION ['equipeA'][0]->getMG()+1);
                      $_SESSION ['equipeA'][3]->setMP($_SESSION ['equipeA'][3]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeA'][0]->setBP($_SESSION ['equipeA'][0]->getBP()+$score9);
                    $_SESSION ['equipeA'][3]->setBP($_SESSION ['equipeA'][3]->getBP()+$score10);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeA'][0]->setBC($_SESSION ['equipeA'][0]->getBC()+$score9);
                    $_SESSION ['equipeA'][3]->setBC($_SESSION ['equipeA'][3]->getBC()+$score10);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][0]->setDIF( $_SESSION ['equipeA'][0]->getBP() - $_SESSION ['equipeA'][0]->getBC() );
                    $_SESSION ['equipeA'][3]->setDIF($_SESSION ['equipeA'][3]->getBP() - $_SESSION ['equipeA'][3]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][0]->setPOINT( $_SESSION ['equipeA'][0]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score10 > $score9){
                      $_SESSION ['equipeA'][0]->setMJ($_SESSION ['equipeA'][0]->getMJ()+1);
                      $_SESSION ['equipeA'][3]->setMJ($_SESSION ['equipeA'][3]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][3]->setMG($_SESSION ['equipeA'][3]->getMG()+1);
                      $_SESSION ['equipeA'][0]->setMP($_SESSION ['equipeA'][0]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeA'][0]->setBP($_SESSION ['equipeA'][0]->getBP()+$score9);
                    $_SESSION ['equipeA'][3]->setBP($_SESSION ['equipeA'][3]->getBP()+$score10);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeA'][0]->setBC($_SESSION ['equipeA'][0]->getBC()+$score10);
                    $_SESSION ['equipeA'][3]->setBC($_SESSION ['equipeA'][3]->getBC()+$score9);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][0]->setDIF( $_SESSION ['equipeA'][0]->getBP() - $_SESSION ['equipeA'][0]->getBC());
                    $_SESSION ['equipeA'][3]->setDIF(   $_SESSION ['equipeA'][3]->getBP() - $_SESSION ['equipeA'][3]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][3]->setPOINT( $_SESSION ['equipeA'][3]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeA'][0]->setMJ($_SESSION ['equipeA'][0]->getMJ()+1);
                      $_SESSION ['equipeA'][3]->setMJ($_SESSION ['equipeA'][3]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeA'][0]->setMN($_SESSION ['equipeA'][0]->getMN()+1);
                      $_SESSION ['equipeA'][3]->setMN($_SESSION ['equipeA'][3]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeA'][0]->setBP($_SESSION ['equipeA'][0]->getBP()+$score9);
                    $_SESSION ['equipeA'][3]->setBP($_SESSION ['equipeA'][3]->getBP()+$score10);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeA'][0]->setBC($_SESSION ['equipeA'][0]->getBC()+$score10);
                    $_SESSION ['equipeA'][3]->setBC($_SESSION ['equipeA'][3]->getBC()+$score9);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][0]->setDIF( $_SESSION ['equipeA'][0]->getBC() -  $_SESSION ['equipeA'][0]->getBP());
                    $_SESSION ['equipeA'][3]->setDIF( $_SESSION ['equipeA'][3]->getBC() -  $_SESSION ['equipeA'][3]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][0]->setPOINT( $_SESSION ['equipeA'][0]->getPOINT()+1);
                        $_SESSION ['equipeA'][3]->setPOINT( $_SESSION ['equipeA'][3]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                  
                }
                
              }
              header("location:./matche.php");
              ?>




              <?php
                  //**************************************TRAITEMENT 6EM MATCH ************************************
                if( isset($_POST['score11']) && isset($_POST['score12']) ) {
                  $score11 = $_POST['score11'];
                  $score12 = $_POST['score12'];
                
                

                  $sc6 = "INSERT INTO scorea VALUES ('','$score11','$score12')";

                  if (mysqli_query($db, $sc6)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc6 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);

                    if($score11 > $score12){
                      $_SESSION ['equipeA'][1]->setMJ($_SESSION ['equipeA'][1]->getMJ()+1);
                      $_SESSION ['equipeA'][2]->setMJ($_SESSION ['equipeA'][2]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][1]->setMG($_SESSION ['equipeA'][1]->getMG()+1);
                      $_SESSION ['equipeA'][2]->setMP($_SESSION ['equipeA'][2]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeA'][1]->setBP($_SESSION ['equipeA'][1]->getBP()+$score11);
                    $_SESSION ['equipeA'][2]->setBP($_SESSION ['equipeA'][2]->getBP()+$score12);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeA'][1]->setBC($_SESSION ['equipeA'][1]->getBC()+$score11);
                    $_SESSION ['equipeA'][2]->setBC($_SESSION ['equipeA'][2]->getBC()+$score12);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][1]->setDIF( $_SESSION ['equipeA'][1]->getBP() - $_SESSION ['equipeA'][1]->getBC() );
                    $_SESSION ['equipeA'][2]->setDIF($_SESSION ['equipeA'][2]->getBP() - $_SESSION ['equipeA'][2]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][1]->setPOINT( $_SESSION ['equipeA'][1]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score12 > $score11){
                      $_SESSION ['equipeA'][1]->setMJ($_SESSION ['equipeA'][1]->getMJ()+1);
                      $_SESSION ['equipeA'][2]->setMJ($_SESSION ['equipeA'][2]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeA'][1]->setMG($_SESSION ['equipeA'][1]->getMG()+1);
                      $_SESSION ['equipeA'][2]->setMP($_SESSION ['equipeA'][2]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeA'][1]->setBP($_SESSION ['equipeA'][1]->getBP()+$score11);
                    $_SESSION ['equipeA'][2]->setBP($_SESSION ['equipeA'][2]->getBP()+$score12);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeA'][1]->setBC($_SESSION ['equipeA'][1]->getBC()+$score12);
                    $_SESSION ['equipeA'][2]->setBC($_SESSION ['equipeA'][2]->getBC()+$score11);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][1]->setDIF( $_SESSION ['equipeA'][1]->getBP() - $_SESSION ['equipeA'][1]->getBC());
                    $_SESSION ['equipeA'][2]->setDIF(   $_SESSION ['equipeA'][2]->getBP() - $_SESSION ['equipeA'][2]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][2]->setPOINT( $_SESSION ['equipeA'][2]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeA'][1]->setMJ($_SESSION ['equipeA'][1]->getMJ()+1);
                      $_SESSION ['equipeA'][2]->setMJ($_SESSION ['equipeA'][2]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeA'][1]->setMN($_SESSION ['equipeA'][1]->getMN()+1);
                      $_SESSION ['equipeA'][2]->setMN($_SESSION ['equipeA'][2]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeA'][1]->setBP($_SESSION ['equipeA'][1]->getBP()+$score11);
                    $_SESSION ['equipeA'][2]->setBP($_SESSION ['equipeA'][2]->getBP()+$score12);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeA'][1]->setBC($_SESSION ['equipeA'][1]->getBC()+$score12);
                    $_SESSION ['equipeA'][2]->setBC($_SESSION ['equipeA'][2]->getBC()+$score11);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeA'][1]->setDIF( $_SESSION ['equipeA'][1]->getBC() -  $_SESSION ['equipeA'][1]->getBP());
                    $_SESSION ['equipeA'][2]->setDIF( $_SESSION ['equipeA'][2]->getBC() -  $_SESSION ['equipeA'][2]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeA'][1]->setPOINT( $_SESSION ['equipeA'][1]->getPOINT()+1);
                        $_SESSION ['equipeA'][2]->setPOINT( $_SESSION ['equipeA'][2]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                  
                }
                
              }
              header("location:./matche.php");
              ?>


              <?php
                  //**************************************TRAITEMENT 7EM MATCH GROUPE B ************************************
                if( isset($_POST['score13']) && isset($_POST['score14']) ) {
                  $score13 = $_POST['score13'];
                  $score14 = $_POST['score14'];
                
                

                  $sc7 = "INSERT INTO scoreb VALUES ('','$score13','$score14')";

                  if (mysqli_query($db, $sc7)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc7 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);

                    if($score13 > $score14){
                      $_SESSION ['equipeB'][0]->setMJ($_SESSION ['equipeB'][0]->getMJ()+1);
                      $_SESSION ['equipeB'][1]->setMJ($_SESSION ['equipeB'][1]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][0]->setMG($_SESSION ['equipeB'][0]->getMG()+1);
                      $_SESSION ['equipeB'][1]->setMP($_SESSION ['equipeB'][1]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeB'][0]->setBP($_SESSION ['equipeB'][0]->getBP()+$score13);
                    $_SESSION ['equipeB'][1]->setBP($_SESSION ['equipeB'][1]->getBP()+$score14);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeB'][0]->setBC($_SESSION ['equipeB'][0]->getBC()+$score13);
                    $_SESSION ['equipeB'][1]->setBC($_SESSION ['equipeB'][1]->getBC()+$score14);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][0]->setDIF( $_SESSION ['equipeB'][0]->getBP() - $_SESSION ['equipeB'][0]->getBC() );
                    $_SESSION ['equipeB'][1]->setDIF($_SESSION ['equipeB'][1]->getBP() - $_SESSION ['equipeB'][1]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][0]->setPOINT( $_SESSION ['equipeB'][0]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score14 > $score13){
                      $_SESSION ['equipeB'][0]->setMJ($_SESSION ['equipeB'][0]->getMJ()+1);
                      $_SESSION ['equipeB'][1]->setMJ($_SESSION ['equipeB'][1]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][1]->setMG($_SESSION ['equipeB'][1]->getMG()+1);
                      $_SESSION ['equipeB'][0]->setMP($_SESSION ['equipeB'][0]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeB'][0]->setBP($_SESSION ['equipeB'][0]->getBP()+$score13);
                    $_SESSION ['equipeB'][1]->setBP($_SESSION ['equipeB'][1]->getBP()+$score14);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeB'][0]->setBC($_SESSION ['equipeB'][0]->getBC()+$score14);
                    $_SESSION ['equipeB'][1]->setBC($_SESSION ['equipeB'][1]->getBC()+$score13);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][0]->setDIF( $_SESSION ['equipeB'][0]->getBP() - $_SESSION ['equipeB'][0]->getBC());
                    $_SESSION ['equipeB'][1]->setDIF(   $_SESSION ['equipeB'][1]->getBP() - $_SESSION ['equipeB'][1]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][1]->setPOINT( $_SESSION ['equipeB'][1]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeB'][0]->setMJ($_SESSION ['equipeB'][0]->getMJ()+1);
                      $_SESSION ['equipeB'][1]->setMJ($_SESSION ['equipeB'][1]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeB'][0]->setMN($_SESSION ['equipeB'][0]->getMN()+1);
                      $_SESSION ['equipeB'][1]->setMN($_SESSION ['equipeB'][1]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeB'][0]->setBP($_SESSION ['equipeB'][0]->getBP()+$score13);
                    $_SESSION ['equipeB'][1]->setBP($_SESSION ['equipeB'][1]->getBP()+$score14);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeB'][0]->setBC($_SESSION ['equipeB'][0]->getBC()+$score14);
                    $_SESSION ['equipeB'][1]->setBC($_SESSION ['equipeB'][1]->getBC()+$score13);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][0]->setDIF( $_SESSION ['equipeB'][0]->getBC() -  $_SESSION ['equipeB'][0]->getBP());
                    $_SESSION ['equipeB'][1]->setDIF( $_SESSION ['equipeB'][1]->getBC() -  $_SESSION ['equipeB'][1]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][0]->setPOINT( $_SESSION ['equipeB'][0]->getPOINT()+1);
                        $_SESSION ['equipeB'][1]->setPOINT( $_SESSION ['equipeB'][1]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                  
                }
                
              }
              header("location:./matche.php");
              ?>



              <?php
                  //**************************************TRAITEMENT 8EM MATCH GROUPE B ************************************
                if( isset($_POST['score15']) && isset($_POST['score16']) ) {
                  $score15 = $_POST['score15'];
                  $score16 = $_POST['score16'];
                
                

                  $sc8 = "INSERT INTO scoreb VALUES ('','$score15','$score16' )";

                  if (mysqli_query($db, $sc8)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc8 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);

                    if($score15 > $score16){
                      $_SESSION ['equipeB'][2]->setMJ($_SESSION ['equipeB'][2]->getMJ()+1);
                      $_SESSION ['equipeB'][3]->setMJ($_SESSION ['equipeB'][3]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][2]->setMG($_SESSION ['equipeB'][2]->getMG()+1);
                      $_SESSION ['equipeB'][3]->setMP($_SESSION ['equipeB'][3]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeB'][2]->setBP($_SESSION ['equipeB'][2]->getBP()+$score15);
                    $_SESSION ['equipeB'][3]->setBP($_SESSION ['equipeB'][3]->getBP()+$score16);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeB'][2]->setBC($_SESSION ['equipeB'][2]->getBC()+$score15);
                    $_SESSION ['equipeB'][3]->setBC($_SESSION ['equipeB'][3]->getBC()+$score16);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][2]->setDIF( $_SESSION ['equipeB'][2]->getBP() - $_SESSION ['equipeB'][2]->getBC() );
                    $_SESSION ['equipeB'][3]->setDIF($_SESSION ['equipeB'][3]->getBP() - $_SESSION ['equipeB'][3]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][2]->setPOINT( $_SESSION ['equipeB'][2]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score16 > $score15){
                      $_SESSION ['equipeB'][2]->setMJ($_SESSION ['equipeB'][2]->getMJ()+1);
                      $_SESSION ['equipeB'][3]->setMJ($_SESSION ['equipeB'][3]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][3]->setMG($_SESSION ['equipeB'][3]->getMG()+1);
                      $_SESSION ['equipeB'][2]->setMP($_SESSION ['equipeB'][2]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeB'][2]->setBP($_SESSION ['equipeB'][2]->getBP()+$score15);
                    $_SESSION ['equipeB'][3]->setBP($_SESSION ['equipeB'][3]->getBP()+$score16);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeB'][2]->setBC($_SESSION ['equipeB'][2]->getBC()+$score16);
                    $_SESSION ['equipeB'][3]->setBC($_SESSION ['equipeB'][3]->getBC()+$score15);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][2]->setDIF( $_SESSION ['equipeB'][2]->getBP() - $_SESSION ['equipeB'][2]->getBC());
                    $_SESSION ['equipeB'][3]->setDIF(   $_SESSION ['equipeB'][3]->getBP() - $_SESSION ['equipeB'][3]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][3]->setPOINT( $_SESSION ['equipeB'][3]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeB'][2]->setMJ($_SESSION ['equipeB'][2]->getMJ()+1);
                      $_SESSION ['equipeB'][3]->setMJ($_SESSION ['equipeB'][3]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeB'][2]->setMN($_SESSION ['equipeB'][2]->getMN()+1);
                      $_SESSION ['equipeB'][3]->setMN($_SESSION ['equipeB'][3]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeB'][2]->setBP($_SESSION ['equipeB'][2]->getBP()+$score15);
                    $_SESSION ['equipeB'][3]->setBP($_SESSION ['equipeB'][3]->getBP()+$score16);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeB'][2]->setBC($_SESSION ['equipeB'][2]->getBC()+$score16);
                    $_SESSION ['equipeB'][3]->setBC($_SESSION ['equipeB'][3]->getBC()+$score15);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][2]->setDIF( $_SESSION ['equipeB'][2]->getBC() -  $_SESSION ['equipeB'][2]->getBP());
                    $_SESSION ['equipeB'][3]->setDIF( $_SESSION ['equipeB'][3]->getBC() -  $_SESSION ['equipeB'][3]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][2]->setPOINT( $_SESSION ['equipeB'][2]->getPOINT()+1);
                        $_SESSION ['equipeB'][3]->setPOINT( $_SESSION ['equipeB'][3]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                    
                    
                
                    
                }
                
              }
              header("location:./matche.php");
              ?>



              <?php
                  //**************************************TRAITEMENT 9EM MATCH GROUPE B ************************************
                if( isset($_POST['score17']) && isset($_POST['score18']) ) {
                  $score17 = $_POST['score17'];
                  $score18 = $_POST['score18'];
                
                

                  $sc9 = "INSERT INTO scoreb VALUES ('','$score17','$score18')";

                  if (mysqli_query($db, $sc9)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc9 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);

                    if($score17 > $score18){
                      $_SESSION ['equipeB'][0]->setMJ($_SESSION ['equipeB'][2]->getMJ()+1);
                      $_SESSION ['equipeB'][2]->setMJ($_SESSION ['equipeB'][3]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][0]->setMG($_SESSION ['equipeB'][2]->getMG()+1);
                      $_SESSION ['equipeB'][2]->setMP($_SESSION ['equipeB'][3]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeB'][0]->setBP($_SESSION ['equipeB'][2]->getBP()+$score17);
                    $_SESSION ['equipeB'][2]->setBP($_SESSION ['equipeB'][3]->getBP()+$score18);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeB'][0]->setBC($_SESSION ['equipeB'][2]->getBC()+$score18);
                    $_SESSION ['equipeB'][2]->setBC($_SESSION ['equipeB'][3]->getBC()+$score17);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][0]->setDIF( $_SESSION ['equipeB'][2]->getBP() - $_SESSION ['equipeB'][2]->getBC() );
                    $_SESSION ['equipeB'][2]->setDIF($_SESSION ['equipeB'][3]->getBP() - $_SESSION ['equipeB'][3]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][0]->setPOINT( $_SESSION ['equipeB'][0]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score18 > $score17){
                      $_SESSION ['equipeB'][0]->setMJ($_SESSION ['equipeB'][0]->getMJ()+1);
                      $_SESSION ['equipeB'][2]->setMJ($_SESSION ['equipeB'][2]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][2]->setMG($_SESSION ['equipeB'][0]->getMG()+1);
                      $_SESSION ['equipeB'][0]->setMP($_SESSION ['equipeB'][2]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeB'][0]->setBP($_SESSION ['equipeB'][0]->getBP()+$score17);
                    $_SESSION ['equipeB'][2]->setBP($_SESSION ['equipeB'][2]->getBP()+$score18);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeB'][0]->setBC($_SESSION ['equipeB'][0]->getBC()+$score18);
                    $_SESSION ['equipeB'][2]->setBC($_SESSION ['equipeB'][2]->getBC()+$score17);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][0]->setDIF( $_SESSION ['equipeB'][0]->getBP() - $_SESSION ['equipeB'][0]->getBC());
                    $_SESSION ['equipeB'][2]->setDIF(   $_SESSION ['equipeB'][2]->getBP() - $_SESSION ['equipeB'][2]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][2]->setPOINT( $_SESSION ['equipeB'][2]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeB'][0]->setMJ($_SESSION ['equipeB'][0]->getMJ()+1);
                      $_SESSION ['equipeB'][2]->setMJ($_SESSION ['equipeB'][2]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeB'][0]->setMN($_SESSION ['equipeB'][0]->getMN()+1);
                      $_SESSION ['equipeB'][2]->setMN($_SESSION ['equipeB'][2]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeB'][0]->setBP($_SESSION ['equipeB'][0]->getBP()+$score17);
                    $_SESSION ['equipeB'][2]->setBP($_SESSION ['equipeB'][2]->getBP()+$score18);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeB'][0]->setBC($_SESSION ['equipeB'][0]->getBC()+$score18);
                    $_SESSION ['equipeB'][2]->setBC($_SESSION ['equipeB'][2]->getBC()+$score17);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][0]->setDIF( $_SESSION ['equipeB'][0]->getBC() -  $_SESSION ['equipeB'][0]->getBP());
                    $_SESSION ['equipeB'][2]->setDIF( $_SESSION ['equipeB'][2]->getBC() -  $_SESSION ['equipeB'][2]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][0]->setPOINT( $_SESSION ['equipeB'][0]->getPOINT()+1);
                        $_SESSION ['equipeB'][2]->setPOINT( $_SESSION ['equipeB'][2]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                  
                }
                
              }
              header("location:./matche.php");
              ?>


              <?php
                  //**************************************TRAITEMENT 10EM MATCH GROUPE B ************************************
                if( isset($_POST['score19']) && isset($_POST['score20']) ) {
                  $score19 = $_POST['score19'];
                  $score20 = $_POST['score20'];
                
                

                  $sc10 = "INSERT INTO scoreb VALUES ('','$score19','$score20')";

                  if (mysqli_query($db, $sc10)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc10 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);

                    if($score19 > $score20){
                      $_SESSION ['equipeB'][1]->setMJ($_SESSION ['equipeB'][1]->getMJ()+1);
                      $_SESSION ['equipeB'][3]->setMJ($_SESSION ['equipeB'][3]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][1]->setMG($_SESSION ['equipeB'][1]->getMG()+1);
                      $_SESSION ['equipeB'][3]->setMP($_SESSION ['equipeB'][3]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeB'][1]->setBP($_SESSION ['equipeB'][1]->getBP()+$score19);
                    $_SESSION ['equipeB'][3]->setBP($_SESSION ['equipeB'][3]->getBP()+$score20);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeB'][1]->setBC($_SESSION ['equipeB'][1]->getBC()+$score20);
                    $_SESSION ['equipeB'][3]->setBC($_SESSION ['equipeB'][3]->getBC()+$score19);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][1]->setDIF( $_SESSION ['equipeB'][1]->getBP() - $_SESSION ['equipeB'][1]->getBC() );
                    $_SESSION ['equipeB'][3]->setDIF($_SESSION ['equipeB'][3]->getBP() - $_SESSION ['equipeB'][3]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][1]->setPOINT( $_SESSION ['equipeB'][1]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score20 > $score19){
                      $_SESSION ['equipeB'][1]->setMJ($_SESSION ['equipeB'][1]->getMJ()+1);
                      $_SESSION ['equipeB'][3]->setMJ($_SESSION ['equipeB'][3]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][3]->setMG($_SESSION ['equipeB'][3]->getMG()+1);
                      $_SESSION ['equipeB'][1]->setMP($_SESSION ['equipeB'][1]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeB'][1]->setBP($_SESSION ['equipeB'][1]->getBP()+$score19);
                    $_SESSION ['equipeB'][3]->setBP($_SESSION ['equipeB'][3]->getBP()+$score20);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeB'][1]->setBC($_SESSION ['equipeB'][1]->getBC()+$score20);
                    $_SESSION ['equipeB'][3]->setBC($_SESSION ['equipeB'][3]->getBC()+$score19);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][1]->setDIF( $_SESSION ['equipeB'][1]->getBP() - $_SESSION ['equipeB'][1]->getBC());
                    $_SESSION ['equipeB'][3]->setDIF(   $_SESSION ['equipeB'][3]->getBP() - $_SESSION ['equipeB'][3]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][3]->setPOINT( $_SESSION ['equipeB'][3]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeB'][1]->setMJ($_SESSION ['equipeB'][1]->getMJ()+1);
                      $_SESSION ['equipeB'][3]->setMJ($_SESSION ['equipeB'][3]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeB'][1]->setMN($_SESSION ['equipeB'][1]->getMN()+1);
                      $_SESSION ['equipeB'][3]->setMN($_SESSION ['equipeB'][3]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeB'][1]->setBP($_SESSION ['equipeB'][1]->getBP()+$score19);
                    $_SESSION ['equipeB'][3]->setBP($_SESSION ['equipeB'][3]->getBP()+$score20);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeB'][1]->setBC($_SESSION ['equipeB'][1]->getBC()+$score20);
                    $_SESSION ['equipeB'][3]->setBC($_SESSION ['equipeB'][3]->getBC()+$score19);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][1]->setDIF( $_SESSION ['equipeB'][1]->getBC() -  $_SESSION ['equipeB'][1]->getBP());
                    $_SESSION ['equipeB'][3]->setDIF( $_SESSION ['equipeB'][3]->getBC() -  $_SESSION ['equipeB'][3]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][1]->setPOINT( $_SESSION ['equipeB'][1]->getPOINT()+1);
                        $_SESSION ['equipeB'][3]->setPOINT( $_SESSION ['equipeB'][3]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                  
                }
                
              }
              header("location:./matche.php");
              ?>


              <?php
                  //**************************************TRAITEMENT 11EM MATCH GROUPE B ************************************
                if( isset($_POST['score21']) && isset($_POST['score22']) ) {
                  $score21 = $_POST['score21'];
                  $score22 = $_POST['score22'];
                
                

                  $sc11 = "INSERT INTO scoreb VALUES ('','$score21','$score22')";

                  if (mysqli_query($db, $sc11)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc11 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);

                    if($score21 > $score22){
                      $_SESSION ['equipeB'][0]->setMJ($_SESSION ['equipeB'][0]->getMJ()+1);
                      $_SESSION ['equipeB'][3]->setMJ($_SESSION ['equipeB'][3]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][0]->setMG($_SESSION ['equipeB'][0]->getMG()+1);
                      $_SESSION ['equipeB'][3]->setMP($_SESSION ['equipeB'][3]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeB'][0]->setBP($_SESSION ['equipeB'][0]->getBP()+$score21);
                    $_SESSION ['equipeB'][3]->setBP($_SESSION ['equipeB'][3]->getBP()+$score22);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeB'][0]->setBC($_SESSION ['equipeB'][0]->getBC()+$score22);
                    $_SESSION ['equipeB'][3]->setBC($_SESSION ['equipeB'][3]->getBC()+$score21);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][0]->setDIF( $_SESSION ['equipeB'][0]->getBP() - $_SESSION ['equipeB'][0]->getBC() );
                    $_SESSION ['equipeB'][3]->setDIF($_SESSION ['equipeB'][3]->getBP() - $_SESSION ['equipeB'][3]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][0]->setPOINT( $_SESSION ['equipeB'][0]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score22 > $score21){
                      $_SESSION ['equipeB'][0]->setMJ($_SESSION ['equipeB'][0]->getMJ()+1);
                      $_SESSION ['equipeB'][3]->setMJ($_SESSION ['equipeB'][3]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][3]->setMG($_SESSION ['equipeB'][3]->getMG()+1);
                      $_SESSION ['equipeB'][0]->setMP($_SESSION ['equipeB'][0]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeB'][0]->setBP($_SESSION ['equipeB'][0]->getBP()+$score21);
                    $_SESSION ['equipeB'][3]->setBP($_SESSION ['equipeB'][3]->getBP()+$score22);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeB'][0]->setBC($_SESSION ['equipeB'][0]->getBC()+$score22);
                    $_SESSION ['equipeB'][3]->setBC($_SESSION ['equipeB'][3]->getBC()+$score21);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][0]->setDIF( $_SESSION ['equipeB'][0]->getBP() - $_SESSION ['equipeB'][0]->getBC());
                    $_SESSION ['equipeB'][3]->setDIF(   $_SESSION ['equipeB'][3]->getBP() - $_SESSION ['equipeB'][3]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][3]->setPOINT( $_SESSION ['equipeB'][3]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
                
                    }else{
                      $_SESSION ['equipeB'][0]->setMJ($_SESSION ['equipeB'][0]->getMJ()+1);
                      $_SESSION ['equipeB'][3]->setMJ($_SESSION ['equipeB'][3]->getMJ()+1);
                
                      //************************************** Matchs Nul ****************************
                      $_SESSION ['equipeB'][0]->setMN($_SESSION ['equipeB'][0]->getMN()+1);
                      $_SESSION ['equipeB'][3]->setMN($_SESSION ['equipeB'][3]->getMN()+1);
                    //************************************** Fin Matchs Nul **************************
                
                    //**************************************  But Marquer ************************************
                    $_SESSION ['equipeB'][0]->setBP($_SESSION ['equipeB'][0]->getBP()+$score21);
                    $_SESSION ['equipeB'][3]->setBP($_SESSION ['equipeB'][3]->getBP()+$score22);
                      //************************************** Fin But Marquer  ********************************
                
                    //************************************** But Encaisser  **************************************
                    $_SESSION ['equipeB'][0]->setBC($_SESSION ['equipeB'][0]->getBC()+$score22);
                    $_SESSION ['equipeB'][3]->setBC($_SESSION ['equipeB'][3]->getBC()+$score21);
                  //************************************** But Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][0]->setDIF( $_SESSION ['equipeB'][0]->getBC() -  $_SESSION ['equipeB'][0]->getBP());
                    $_SESSION ['equipeB'][3]->setDIF( $_SESSION ['equipeB'][3]->getBC() -  $_SESSION ['equipeB'][3]->getBP());
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][0]->setPOINT( $_SESSION ['equipeB'][0]->getPOINT()+1);
                        $_SESSION ['equipeB'][3]->setPOINT( $_SESSION ['equipeB'][3]->getPOINT()+1);
                    //**************************************Fin Ajout des Point ************************************
                  
                }
                
              }
              header("location:./matche.php");
              ?>


              <?php
                  //**************************************TRAITEMENT 12EM MATCH  GROUPE B************************************
                if( isset($_POST['score23']) && isset($_POST['score24']) ) {
                  $score23 = $_POST['score23'];
                  $score24 = $_POST['score24'];
                
                

                  $sc12 = "INSERT INTO scoreb VALUES ('','$score23','$score24')";

                  if (mysqli_query($db, $sc12)) {
                    echo "New record created successfully";
                      
                  } else {
                    echo "Error: " . $sc12 . "<br>" . mysqli_error($db);
                  }
                  
                  

                    mysqli_close($db);

                    if($score23 > $score24){
                      $_SESSION ['equipeB'][1]->setMJ($_SESSION ['equipeB'][1]->getMJ()+1);
                      $_SESSION ['equipeB'][2]->setMJ($_SESSION ['equipeB'][2]->getMJ()+1);

                      
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][1]->setMG($_SESSION ['equipeB'][1]->getMG()+1);
                      $_SESSION ['equipeB'][2]->setMP($_SESSION ['equipeB'][2]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer   ************************************
                    $_SESSION ['equipeB'][1]->setBP($_SESSION ['equipeB'][1]->getBP()+$score23);
                    $_SESSION ['equipeB'][2]->setBP($_SESSION ['equipeB'][2]->getBP()+$score24);
                      //************************************** Fin But Marquer r ********************************
                
                    //************************************** But  Encaisser**************************************
                    $_SESSION ['equipeB'][1]->setBC($_SESSION ['equipeB'][1]->getBC()+$score24);
                    $_SESSION ['equipeB'][2]->setBC($_SESSION ['equipeB'][2]->getBC()+$score23);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][1]->setDIF( $_SESSION ['equipeB'][1]->getBP() - $_SESSION ['equipeB'][1]->getBC() );
                    $_SESSION ['equipeB'][2]->setDIF($_SESSION ['equipeB'][2]->getBP() - $_SESSION ['equipeB'][2]->getBC() );
                    //************************************** Fin Difference De But *********************************
                    
                    //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][1]->setPOINT( $_SESSION ['equipeB'][1]->getPOINT()+3);
                    //**************************************Fin Ajout des Point ************************************
                
                    }else if($score24 > $score23){
                      $_SESSION ['equipeB'][1]->setMJ($_SESSION ['equipeB'][1]->getMJ()+1);
                      $_SESSION ['equipeB'][2]->setMJ($_SESSION ['equipeB'][2]->getMJ()+1);
                
                      //************************************** Matchs Gagner et Matchs Perdue *********************
                      $_SESSION ['equipeB'][1]->setMG($_SESSION ['equipeB'][1]->getMG()+1);
                      $_SESSION ['equipeB'][2]->setMP($_SESSION ['equipeB'][2]->getMP()+1);
                    //************************************** Fin Matchs Gagner et Matchs Perdue *****************
                
                    //************************************** But Marquer  ************************************
                    $_SESSION ['equipeB'][1]->setBP($_SESSION ['equipeB'][1]->getBP()+$score23);
                    $_SESSION ['equipeB'][2]->setBP($_SESSION ['equipeB'][2]->getBP()+$score24);
                      //************************************** Fin But Marquer  ********************************
                
                    //**************************************  But Encaisser **************************************
                    $_SESSION ['equipeB'][1]->setBC($_SESSION ['equipeB'][1]->getBC()+$score24);
                    $_SESSION ['equipeB'][2]->setBC($_SESSION ['equipeB'][2]->getBC()+$score23);
                  //************************************** Fin Encaisser ********************************
                
                  //************************************** Diffenrence De But *******************************
                    $_SESSION ['equipeB'][1]->setDIF( $_SESSION ['equipeB'][1]->getBP() - $_SESSION ['equipeB'][1]->getBC());
                    $_SESSION ['equipeB'][2]->setDIF(   $_SESSION ['equipeB'][2]->getBP() - $_SESSION ['equipeB'][2]->getBC());
                        //************************************** Fin Difference De But *********************************
                    
                        //************************************** Ajout des Points **************************************
                        $_SESSION ['equipeB'][2]->setPOINT( $_SESSION ['equipeB'][2]->getPOINT()+3);
                        //**************************************Fin Ajout des Point ************************************
    
        }else{
          $_SESSION ['equipeB'][1]->setMJ($_SESSION ['equipeB'][1]->getMJ()+1);
          $_SESSION ['equipeB'][2]->setMJ($_SESSION ['equipeB'][2]->getMJ()+1);
    
          //************************************** Matchs Nul ****************************
          $_SESSION ['equipeB'][1]->setMN($_SESSION ['equipeB'][1]->getMN()+1);
          $_SESSION ['equipeB'][2]->setMN($_SESSION ['equipeB'][2]->getMN()+1);
        //************************************** Fin Matchs Nul **************************
    
        //**************************************  But Marquer ************************************
        $_SESSION ['equipeB'][1]->setBP($_SESSION ['equipeB'][1]->getBP()+$score23);
        $_SESSION ['equipeB'][2]->setBP($_SESSION ['equipeB'][2]->getBP()+$score24);
          //************************************** Fin But Marquer  ********************************
    
        //************************************** But Encaisser  **************************************
        $_SESSION ['equipeB'][1]->setBC($_SESSION ['equipeB'][1]->getBC()+$score24);
        $_SESSION ['equipeB'][2]->setBC($_SESSION ['equipeB'][2]->getBC()+$score23);
      //************************************** But Encaisser ********************************
    
      //************************************** Diffenrence De But *******************************
        $_SESSION ['equipeB'][1]->setDIF( $_SESSION ['equipeB'][1]->getBC() -  $_SESSION ['equipeB'][1]->getBP());
        $_SESSION ['equipeB'][2]->setDIF( $_SESSION ['equipeB'][2]->getBC() -  $_SESSION ['equipeB'][2]->getBP());
        //************************************** Fin Difference De But *********************************
        
        //************************************** Ajout des Points **************************************
            $_SESSION ['equipeB'][1]->setPOINT( $_SESSION ['equipeB'][1]->getPOINT()+1);
            $_SESSION ['equipeB'][2]->setPOINT( $_SESSION ['equipeB'][2]->getPOINT()+1);
        //**************************************Fin Ajout des Point ************************************
      
    }
}
 header("location:./matche.php");
?>

  <?php
      //TRAITEMENT POUR LA DEMI FINALE
     if(isset($_POST['sc1']) && isset ($_POST['sc2'])){

          $score1 = $_POST['sc1'];
          $score2 = $_POST['sc2'];

          

          $sql = "INSERT INTO scoredemi1 VALUES ('','$score1','$score2')";
          $result = mysqli_query($db, $sql); 

          
          $equipeQualif = $_SESSION['demiFinalea'][0];
          $equipeQualif2 = $_SESSION['demiFinaleb'][1];

          
          
        
          if ($score1 === $score2) 
          {
            $tiraubut = rand(0,5);
            $tiraubut4 = rand(0,5);
    
            while($tiraubut === $tiraubut4)
            {
              $tiraubut = rand(0,5);
              $tiraubut4 = rand(0,5);
              break;
            }
              //alert("<?php echo "Bonjour";>");
             if ($tiraubut > $tiraubut4) 
            {
              
                 $sql = "INSERT INTO final VALUES (null, '$equipeQualif')";
                 mysqli_query($db, $sql);
    
                 $sql = "INSERT INTO finalp VALUES (null, '$equipeQualif2')";
                 mysqli_query($db, $sql);
                   
            }
            else
             {
                $sql = "INSERT INTO final VALUES (null, '$equipeQualif2')";
                mysqli_query($db, $sql);

                $sql = "INSERT INTO finalp VALUES (null, '$equipeQualif')";
                mysqli_query($db, $sql);

                 header("location:./dmFinal.php");
            }

          } 
			    
    

          else if($score1 > $score2) 
            {
              $sql = "INSERT INTO final VALUES ('', '$equipeQualif')";
              mysqli_query($db, $sql);

              $sql = "INSERT INTO finalp VALUES ('', '$equipeQualif2')";
                mysqli_query($db, $sql);

                header("location:./dmFinal.php");  
           }
        
          else
			     {
              $sql = "INSERT INTO final VALUES ('', '$equipeQualif2')";
                mysqli_query($db, $sql);

              $sql = "INSERT INTO finalp VALUES ('', '$equipeQualif')";
                mysqli_query($db, $sql);
			      
            header("location:./dmFinal.php");
           }
            
      }
?> 

<?php
      //TRAITEMENT POUR LA DEMI FINALE
     if(isset($_POST['sc3']) && isset ($_POST['sc4'])){

          $score3 = $_POST['sc3'];
          $score4 = $_POST['sc4'];

          $sql = "INSERT INTO scoredemi2 VALUES ('','$score3','$score4')";
          $result = mysqli_query($db, $sql); 

          $equipeQualif3 = $_SESSION['demiFinalea'][1];
          $equipeQualif1 = $_SESSION['demiFinaleb'][0];
        
          if ($score3 === $score4) 
          {
            $tiraubut = rand(0,5);
            $tiraubut4 = rand(0,5);
    
            while($tiraubut === $tiraubut4)
            {
              $tiraubut = rand(0,5);
              $tiraubut4 = rand(0,5);
              break;
            }
    
            if ($tiraubut > $tiraubut4) 
            {
              $sql = "INSERT INTO final VALUES ('', '$equipeQualif3')";
                 mysqli_query($db, $sql);
    
                 $sql = "INSERT INTO finalp VALUES ('', '$equipeQualif1')";
                 mysqli_query($db, $sql);
            }
            else
            {
                $sql = "INSERT INTO final VALUES ('', '$equipeQualif1')";
                mysqli_query($db, $sql);

                $sql = "INSERT INTO finalp VALUES ('', '$equipeQualif3')";
                mysqli_query($db, $sql);
            }

               header("location:./dmFinal.php"); 
			    }
    

         else if($score3 > $score4) 
            {
              $sql = "INSERT INTO final VALUES ('', '$equipeQualif3')";
                mysqli_query($db, $sql);

              $sql = "INSERT INTO finalp VALUES ('', '$equipeQualif1')";
                mysqli_query($db, $sql);

             
               header("location:./dmFinal.php");
           } 
          
          else
			     {
              $sql = "INSERT INTO final VALUES ('', '$equipeQualif1')";
              mysqli_query($db, $sql);

              $sql = "INSERT INTO finalp VALUES ('', '$equipeQualif3')";
              mysqli_query($db, $sql);
                
			      }
           
            header("location:./dmFinal.php");

      }

       //*************TRAITEMENT POUR LA 3EM PLACE****************************************
        if(isset($_POST['but1']) && isset ($_POST['but2'])){

          $score7 = $_POST['but1'];
          $score8 = $_POST['but2'];

          $sql = "INSERT INTO scorep VALUES ('','$score7','$score8')";
          $result = mysqli_query($db, $sql); 

          $i = 0;
          $sql = "SELECT equipe FROM finalp";
          $result = mysqli_query($db,$sql);

          if (mysqli_num_rows($result) > 0) {

            echo "<table class='groupe'>";  
            echo "<tr class='header'><th> 3EM PLACE</th></tr>";
            while($row = mysqli_fetch_array($result)){

                $_SESSION['tifinale'][$i] = $row['equipe'];
                $i+=1;
            }
          }
          
          $tifinale2 = $_SESSION['tifinale'][1];
          $tifinale1 = $_SESSION['tifinale'][0];

          
          
        
          if ($score7 === $score8) 
          {
            $tiraubut = rand(0,5);
            $tiraubut4 = rand(0,5);

            while($tiraubut === $tiraubut4)
            {
              $tiraubut = rand(0,5);
              $tiraubut4 = rand(0,5);
              break;
            }
              //alert("<?php echo "Bonjour";>");
            if ($tiraubut > $tiraubut4) 
            {
              $sql = "INSERT INTO 3emplace VALUES ('', '$tifinale1')";
                mysqli_query($db, $sql);

               
            }
            else
            {
              $sql = "INSERT INTO 3emplace VALUES ('', '$tifinale2')";
              mysqli_query($db, $sql);
            }

            header("location:./dmFinal.php");
          }


          else if($score7 > $score8) 
            {
              
              $sql = "INSERT INTO 3emplace VALUES ('', '$tifinale1')";
                mysqli_query($db, $sql);

              
                header("location:./dmFinal.php");
          } 
          
          else
          {
               $sql = "INSERT INTO 3emplace VALUES ('', '$tifinale2')";
                  mysqli_query($db, $sql);

                  
              header("location:./dmFinal.php");
            }
            
      }
    



            //TRAITEMENT POUR LA FINAL
          if(isset($_POST['but3']) && isset ($_POST['but4'])){

                $score5 = $_POST['but3'];
                $score6 = $_POST['but4'];

                $sql = "INSERT INTO scoref VALUES ('','$score5','$score6')";
                $result = mysqli_query($db, $sql); 

                $i = 0;
                  $sql = "SELECT equipe FROM final";
                  $result = mysqli_query($db,$sql);

                  if (mysqli_num_rows($result) > 0) {

                    echo "<table class='groupe'>";  
                    echo "<tr class='header'><th> 3EM PLACE</th></tr>";
                    while($row = mysqli_fetch_array($result)){

                        $_SESSION['grandefinale'][$i] = $row['equipe'];
                        $i+=1;
                    }
                  }

                  $grandefinale2 = $_SESSION['grandefinale'][1];
                  $grandefinale1 = $_SESSION['grandefinale'][0];
        
              
                if ($score5 === $score6) 
                {
                  $tiraubut = rand(0,5);
                  $tiraubut4 = rand(0,5);
          
                  while($tiraubut === $tiraubut4)
                  {
                    $tiraubut = rand(0,5);
                    $tiraubut4 = rand(0,5);
                    break;
                  }
          
                  if ($tiraubut > $tiraubut4) 
                  {
                    $sql = "INSERT INTO champion VALUES ('', '$grandefinale2')";
                      mysqli_query($db, $sql);
          
                  }
                  else
                  {
                      $sql = "INSERT INTO champion VALUES ('', '$grandefinale1')";
                      mysqli_query($db, $sql);

                  }

                  header("location:./Final.php");
                }
          

              else if($score5 > $score6) 
                  {
                    $sql = "INSERT INTO champion VALUES ('', '$grandefinale1')";
                    if(mysqli_query($db, $sql)){

                    }else {
                        echo "ERREUR:" .mysqli_error($db);
                
                      }

                      header("location:./Final.php");
                } 
                
                else
                {
                    $sql = "INSERT INTO champion VALUES ('', '$grandefinale2')";
                    mysqli_query($db, $sql);
                      header("location:./Final.php");
                  }
                
                

            }
  
  ?>

  