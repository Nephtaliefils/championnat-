<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="styl.css" />
</head>
<body>

<?php
require('db.php');
if (isset($_REQUEST['username'], $_REQUEST['email'], $_REQUEST['password'])){
  // récupérer le nom d'utilisateur et supprimer les antislashes ajoutés par le formulaire
  $username = stripslashes($_REQUEST['username']);
  $username = mysqli_real_escape_string($db, $username); 
  // récupérer l'email et supprimer les antislashes ajoutés par le formulaire
  $email = stripslashes($_REQUEST['email']);
  $email = mysqli_real_escape_string($db, $email);
  // récupérer le mot de passe et supprimer les antislashes ajoutés par le formulaire
  $password = stripslashes($_REQUEST['password']);
  $password = mysqli_real_escape_string($db, $password);
  //requéte SQL 
    $query = "INSERT into `users` (username, email, password)
              VALUES ('$username', '$email',  $password)";
  // Exécuter la requête sur la base de données
    $res = mysqli_query($db, $query);
    if($res){
       echo "<div class='sucess'>
             <h3>Vous êtes inscrit avec succès.</h3>
             <p>Cliquez ici pour vous <a href='index.php'>connecter</a></p>
       </div>";
    }
}else{
?>
<div class="container">
   <div class="brand-title">LOGIN!</div>
       <div class="inputs">
            <form  action="" method="post">
                <h1 class="box-title">S'inscrire</h1>
                <label for="username">Utilisateur</label> 
                <input type="text" name="username" placeholder="Nom d'utilisateur" required />
              <br/><br/>
                <label for="email">Email</label>
                <input type="text" name="email" placeholder="Email" required />
              <br/><br/> 
                <label for="password">Mot de passe</label>
                <input type="password"  name="password" placeholder="Mot de passe" required />
              <br/><br/> 

                <button type="submit" name="submit">S'inscrire</button>
                <p >Utilisateur!<a class="ins" href="index.php"> Connectez-vous ici</a></p>
            </form>
        </div>
      </div>
</div>
<?php } ?>

   <div>
      <img src="flag/ro.png " width=80% class="ro">
   </div>
</body>
</html>