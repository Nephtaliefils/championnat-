<?php
include './objet.php';
include './db.php';
 session_start();
   $_SESSION['adp'] = 0;
    if(isset($_SESSION['adp']) && $_SESSION['adp']==0){
       
    }else{
      header('location:./index.php');
    }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styless.css">
  <title>CHAMPIONNAT</title>
</head>
<body>
  
<body class="body">
    <?php
        
    ?>
    <header class="tete">
  <h1>Coupe 3e Infos</h1>
 </header>
        <nav class="menu">
        <ul>
            <li>
                <a href="#">
                    <h2>Tirage</h2>
                </a>
            </li>
            <li>
                <a href="matche.php">
                    <h2>Macthes</h2>
                </a>
            </li>
            <li>
                <a href="classement.php">
                    <h2>Classement</h2>
                </a>
            </li>
            <li>
            <a href="logout.php">Déconnexion</a>
            </li>
            <li>
                
           </li>
        </ul>
        
        </nav>
       
    <?php
      // if(isset($_SESSION['equipe']) && $_SESSION['equipe']!=1){
        if(isset($_SESSION['done']) && $_SESSION['done']==0){
        $equipe = ['Bresil','Argentine','France','Italie','Espagne','Allemagne','Portugal','Haiti'];
        $_SESSION['done'] = 1;
            $groupeA;
            $groupeB;
            $j = 0;   
            $pl = 0;
      
              for($i=0; $i<4; $i++){
                $result = rand(0,1);
                $result += $j;
      
                  if($result %2 == 0){   
                    $_SESSION['groupeA'][$pl] = $equipe [$result];
                    $_SESSION['groupeB'][$pl] =  $equipe [$result+1];
                  
                   $pl++;
                  }
                  else{
                    $_SESSION['groupeA'][$pl] = $equipe [$result];
                    $_SESSION['groupeB'][$pl] = $equipe [$result-1];
                    $pl++;
                  }
                    $j+=2;    
              }
                $_SESSION['equipe'] = 1;
        

          for($i=0; $i<4; $i++){

            $_SESSION ['equipeA'][$i] = new Equipe($_SESSION['groupeA'][$i],0,0,0,0,0,0,0,0);
            $name = "". $_SESSION['groupeA'][$i];
            $sql = "SELECT count(*) FROM classement";
            $exsql =  mysqli_query($db, $sql);
            $res =   mysqli_fetch_array($exsql);
            $nbl = $res['count(*)'];
 
            if($nbl < 4){
            $sql_ok = "INSERT INTO classement VALUES('($i+1)','$name', 0,0,0,0,0,0,0,0)";
            $c = mysqli_query($db, $sql_ok);
                   if($c){
                      // echo "ok";
                   }else {
                     echo "ERREUR:" .mysqli_error($db);
                   }
             }
          }
          for($i=0; $i<4; $i++){

              $_SESSION ['equipeB'][$i] = new Equipe($_SESSION['groupeB'][$i],0,0,0,0,0,0,0,0);
              $name = "". $_SESSION['groupeB'][$i];
              $sql = "SELECT count(*) FROM classementb";
              $exsql =  mysqli_query($db, $sql);
              $res =   mysqli_fetch_array($exsql);
              $nbl = $res['count(*)'];
 
                if($nbl < 4){
                $sql_ok = "INSERT INTO classementb VALUES('($i+1)','$name', 0,0,0,0,0,0,0,0)";
                $c = mysqli_query($db, $sql_ok);
                      if($c){
                          // echo "ok";
                      }else {
                        echo "ERREUR:" .mysqli_error($db);
                      }
              }
        }
          //$_SESSION['disable'] = [];
      }
	  ?>



   <?php
   
    for($i=0; $i<4; $i++)
     {
            $groupeA[$i] = $_SESSION['groupeA'][$i];
            $sql = "SELECT count(*) FROM groupea";
            $exsql =  mysqli_query($db, $sql);
            $res =   mysqli_fetch_array($exsql);
            $nbl = $res['count(*)'];
 
            if($nbl < 4){
              $insrt = "INSERT INTO groupea VALUES ('','$groupeA[$i]')";
              if(mysqli_query($db, $insrt)){

              }else {
                echo "ERREUR:" .mysqli_error($db);
              }
            }
            
            $groupeB[$i] = $_SESSION['groupeB'][$i];
            $sql2 = "SELECT count(*) FROM groupeb";
            $exsql2 =  mysqli_query($db, $sql2);
            $res2 =   mysqli_fetch_array($exsql2);
            $nbl2 = $res2['count(*)'];
            if($nbl2 < 4)
            {
             $insrt2 =  "INSERT INTO groupeb VALUES ('','$groupeB[$i]')";
             if(mysqli_query($db, $insrt2)){

             }else {
               echo "ERREUR:" .mysqli_error($db);
            }

      }
    }
      
  ?> 
<!--------  groupe A $ B -------->
      <?php
        $sql = "SELECT equipe FROM groupea";
        $result = mysqli_query($db, $sql);
        
        if (mysqli_num_rows($result) > 0) {
          
           echo "<table class='groupe'>";  
            echo "<tr class='header'><th>GroupeA</th></tr>";

          while($row = mysqli_fetch_array($result)){
          echo "<tr>";
            echo "<td>" .$row['equipe']. "</td>";
            echo "</tr>";
          }
           mysqli_free_result($result);
          
          echo"</table>";
        } else {
          echo "";
          echo "Erreur:".mysqli_error($db);
        }
        
        
        $sql2 = "SELECT equipe FROM groupeb";
        $result2 = mysqli_query($db, $sql2);
        
        if (mysqli_num_rows($result2) > 0) {
           echo "<table class='groupe1'>";  
            echo "<tr class='header'><th>GroupeB</th></tr>";

          while($row = mysqli_fetch_array($result2)){
            echo "<tr>";
              echo "<td>" .$row['equipe']. "</td>";
            echo "</tr>";
          }
           mysqli_free_result($result2);
          echo"</table>";
        } else {
          echo "";
          echo "Erreur:".mysqli_error($db);
        } 
      ?>    
    </body>
 </html>



