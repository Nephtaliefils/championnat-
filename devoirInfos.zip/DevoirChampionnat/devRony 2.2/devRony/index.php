<?php
require('db.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="styl.css" />
</head>
<body>

<?php
if (isset($_POST['username'])){
  $username = stripslashes($_REQUEST['username']);
  $username = mysqli_real_escape_string($db, $username);
  $password = stripslashes($_REQUEST['password']);
  $password = mysqli_real_escape_string($db, $password);
    $query = "SELECT * FROM `users` WHERE username='$username' and password= $password";
  $result = mysqli_query($db,$query) or die(mysql_error());
  $rows = mysqli_num_rows($result);
  if($rows==1){
      $_SESSION['username'] = $username;
      $_SESSION['password'] = $password;
       $_SESSION['adp'] = 0;
      header("Location:./tournoi.php");
  }else{
    
    $message = "Le nom d'utilisateur ou le mot de passe est incorrect.";
  }
}
?>
  
<div class="container">
   <div class="brand-title">LOGIN!</div>
       <div class="inputs">
          <form  action="" method="post" name="login">
          <label for="username">Utilisateur</label> 
          <input type="text"  name="username" placeholder="Nom d'utilisateur" required="">
          <br/><br/>
          
          <label for="password">Mot de passe</label>
          <input type="password"  name="password" placeholder="Mot de passe" required="">
          <br/><br/> 

          <button type="submit" name="submit" >Connecter</button>
          <p class="pp">Etre Vous un utilisateur? <a href="register.php">S'inscrire</a></p>
              <?php if (! empty($message)) { ?>
                  <p class="errorMessage"><?php echo $message; ?></p>
              <?php } ?>
          </form>
       </div>
    </div>
</div>
   <div>
      <img src="flag/mb.png" width=65% class="mb">
   </div>
</body>
</html>