<?php 

class Equipe {
    private $name;
    private $mJ;
    private $mG;
    private $mN;
    private $mP;
    private $bP;
    private $bC;
    private $dif;
    private $point;

    

    public function __construct($name , $mJ , $mG , $mN , $mP , $bP , $bC , $dif , $point ) {
        $this->name = $name;
        $this->mJ = $mJ;
        $this->mG = $mG;
        $this->mN = $mN;
        $this->mP = $mP;
        $this->bP = $bP;
        $this->bC = $bC;
        $this->dif = $dif;
        $this->point = $point;
    }
    
   public function getName(){
        return  $this->name;
    }

    public function getMJ(){
        return  $this->mJ;
    }

    public function getMG(){
        return  $this->mG;
    }
    
    public function getMN(){
        return  $this->mN;
    }

    public function getMP(){
        return  $this->mP;
    }

    public function getBP(){
        return  $this->bP;
    }

    public function getBC(){
        return  $this->bC;
    }

    public function getDIF(){
        return  $this->dif;
    }

    public function getPOINT(){
        return  $this->point;
    }

    public function setName($name){
         $this->name = $name;
    }

    public function setMJ($mJ){
        $this->mJ = $mJ;
   }

   public function setMG($mG){
    $this->mG = $mG;
   }

   public function setMN($mN){
    $this->mN = $mN;
   }

   public function setMP($mP){
   $this->mP = $mP;
  }

  public function setBP($bP){
    $this->bP = $bP;
   }

   public function setBC($bC){
    $this->bC = $bC;
   }

   public function setDIF($dif){
   $this->dif = $dif;
  }

  public function setPOINT($point){
  $this->point = $point;
  }        
}

?>