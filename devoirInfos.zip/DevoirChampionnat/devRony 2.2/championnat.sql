-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2021 at 11:12 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `championnat`
--

-- --------------------------------------------------------

--
-- Table structure for table `3emplace`
--

CREATE TABLE `3emplace` (
  `id` int(10) NOT NULL,
  `Equipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `champion`
--

CREATE TABLE `champion` (
  `id` int(10) NOT NULL,
  `Equipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `classement`
--

CREATE TABLE `classement` (
  `no` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `mj` int(11) NOT NULL,
  `mg` int(11) NOT NULL,
  `mn` int(11) NOT NULL,
  `mp` int(11) NOT NULL,
  `bp` int(11) NOT NULL,
  `bc` int(11) NOT NULL,
  `dif` int(11) NOT NULL,
  `nbpoint` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `classementb`
--

CREATE TABLE `classementb` (
  `no` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `mj` int(11) NOT NULL,
  `mg` int(11) NOT NULL,
  `mn` int(11) NOT NULL,
  `mp` int(11) NOT NULL,
  `bp` int(11) NOT NULL,
  `bc` int(11) NOT NULL,
  `dif` int(11) NOT NULL,
  `nbpoint` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `disabled_btn`
--

CREATE TABLE `disabled_btn` (
  `id` int(11) NOT NULL,
  `btn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `final`
--

CREATE TABLE `final` (
  `id` int(20) NOT NULL,
  `Equipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `finalp`
--

CREATE TABLE `finalp` (
  `id` int(20) NOT NULL,
  `Equipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `groupea`
--

CREATE TABLE `groupea` (
  `id` int(11) NOT NULL,
  `Equipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `groupeb`
--

CREATE TABLE `groupeb` (
  `id` int(11) NOT NULL,
  `Equipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `quardfinalea`
--

CREATE TABLE `quardfinalea` (
  `id` int(11) NOT NULL,
  `Equipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `quardfinaleb`
--

CREATE TABLE `quardfinaleb` (
  `id` int(11) NOT NULL,
  `Equipe` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scorea`
--

CREATE TABLE `scorea` (
  `id` int(11) NOT NULL,
  `score1` int(11) NOT NULL,
  `score2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scoreb`
--

CREATE TABLE `scoreb` (
  `id` int(11) NOT NULL,
  `score1` int(11) NOT NULL,
  `score2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scoredemi1`
--

CREATE TABLE `scoredemi1` (
  `id` int(20) NOT NULL,
  `scoredf1` int(20) NOT NULL,
  `scoredf2` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scoredemi2`
--

CREATE TABLE `scoredemi2` (
  `id` int(20) NOT NULL,
  `scoredf1` int(11) NOT NULL,
  `scoredf2` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scoref`
--

CREATE TABLE `scoref` (
  `id` int(20) NOT NULL,
  `score1` int(20) NOT NULL,
  `score2` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scorep`
--

CREATE TABLE `scorep` (
  `id` int(11) NOT NULL,
  `score1` int(11) NOT NULL,
  `score2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'Albert', 'germaalbert@gmail.com', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `3emplace`
--
ALTER TABLE `3emplace`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `champion`
--
ALTER TABLE `champion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classement`
--
ALTER TABLE `classement`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `classementb`
--
ALTER TABLE `classementb`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `disabled_btn`
--
ALTER TABLE `disabled_btn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `final`
--
ALTER TABLE `final`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `finalp`
--
ALTER TABLE `finalp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groupea`
--
ALTER TABLE `groupea`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groupeb`
--
ALTER TABLE `groupeb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quardfinalea`
--
ALTER TABLE `quardfinalea`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quardfinaleb`
--
ALTER TABLE `quardfinaleb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scorea`
--
ALTER TABLE `scorea`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scoreb`
--
ALTER TABLE `scoreb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scoredemi1`
--
ALTER TABLE `scoredemi1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scoredemi2`
--
ALTER TABLE `scoredemi2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scoref`
--
ALTER TABLE `scoref`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scorep`
--
ALTER TABLE `scorep`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `3emplace`
--
ALTER TABLE `3emplace`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `champion`
--
ALTER TABLE `champion`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `classement`
--
ALTER TABLE `classement`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `classementb`
--
ALTER TABLE `classementb`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `disabled_btn`
--
ALTER TABLE `disabled_btn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `final`
--
ALTER TABLE `final`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `finalp`
--
ALTER TABLE `finalp`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groupea`
--
ALTER TABLE `groupea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groupeb`
--
ALTER TABLE `groupeb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quardfinalea`
--
ALTER TABLE `quardfinalea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quardfinaleb`
--
ALTER TABLE `quardfinaleb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scorea`
--
ALTER TABLE `scorea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scoreb`
--
ALTER TABLE `scoreb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scoredemi1`
--
ALTER TABLE `scoredemi1`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scoredemi2`
--
ALTER TABLE `scoredemi2`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scoref`
--
ALTER TABLE `scoref`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scorep`
--
ALTER TABLE `scorep`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
